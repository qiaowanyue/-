<?php
if(!isset($_SESSION)){ session_start();}
include("conn/conn.php");
?>
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="keywords" content="桶装水配送系统，谯皖粤，qiao，学生网页，学生，个人作品" />
		<meta name="description" content="这是有个自己制作的桶装水配送系统，运用了bootstrap,css+html5,php+mysql,javascript,ajax">
		<meta http-equiv="refresh" content="800" />
		<title>个人中心</title>
		<script src="js/jquery.min.js" type="text/javascript"></script>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/bootstrap.min.js" type="text/javascript"></script>
		<link href="css/geren.css" rel="stylesheet">
	</head>
	<script type="text/javascript">
		window.onload = function() {
			//判断用户是否登录开始
			var loginUser = document.getElementById("loginUser"); //显示登陆状态的id
			var inPersonal = document.getElementById("inpersonal"); //显示登陆后页面内容的id
			var inPersonalOut = document.getElementById("inpersonalOut"); //显示未登陆页面内容的id
			var xhr = new XMLHttpRequest();
			xhr.open("POST", "back/checkUserLoginStatus.php", true);
			xhr.send();
			xhr.onreadystatechange = function() {
				if(xhr.status == 200 && xhr.readyState == 4) {
					var data = xhr.responseText;
					//					console.log(typeof data);
					data = JSON.parse(data);
					//					console.log(data);
					/* 判断用户是否登录开始 */
					if(data.status == "error") { //用户未登录
						loginUser.innerHTML = '<a href="login.html">登录</a><a href="register.html" style="padding-right: 15px; padding-left:15px">注册</a>';
						inPersonalOut.innerHTML = '<div style="padding: 70px 0px 80px 0px;"><img class="img-thumbnail" src="images/loginout.png" / ></div>';
						inPersonal.style.display = "none"; //设置整个div的内容不显示

					} else if(data.status == "ok") { //用户登录
						loginUser.innerHTML = '欢迎你！<span>' + data.data + '</span><a href="back/logout.php" style="padding-right: 15px; padding-left:15px">注销</a>';
					}
				}
			}
			/* 判断用户是否登录结束 */

			/* 显示用户的基本信息 */
			var outContent = document.getElementById("outContent");
			var xhr1 = new XMLHttpRequest();
			xhr1.open("POST", "back/geren.php", true);
			xhr1.send();
			xhr1.onreadystatechange = function() {
				if(xhr1.status == 200 && xhr1.readyState == 4) {
					var data1 = xhr1.responseText;
					data1 = JSON.parse(data1);
					console.log(data1);
					//					for(var i=0;i<data1.length;i++){
					var i = 0;
					outContent.innerHTML = '<table class="table1"><tr><td>昵称：</td><td align="center"><div class="box">' + data1[i].nickname + '</div></td></tr><tr><td>姓名：</td><td align="center"><div class="box">' + data1[i].name + '</div></td></tr><tr><td>默认送水地址:</td><td align="center"><div class="box">' + data1[i].address + '</div></td></tr><tr><td>电话1:</td><td align="center"><div class="box">' + data1[i].u_mobile1 + '</div></td></tr><tr><td>电话2:</td><td align="center"><div class="box">' + data1[i].u_mobile2 + '</div></td></tr></table>';
					//					}
					document.getElementById('name').value = data1[i].name;
					document.getElementById('tel1').value = data1[i].u_mobile1;
					if(data1[i].u_mobile2 == '无') data1[i].u_mobile2 = '';
					document.getElementById('tel2').value = data1[i].u_mobile2;
				}
			}
		}

		/* 判断修改密码 */
		function cheData() {
			var oldPwd = document.getElementById("oldPwd"); //原密码
			var newPwd = document.getElementById("newPwd"); //新密码
			var chePwd = document.getElementById("chePwd"); //确定密码
			if(oldPwd.value == "") {
				alert("请输入原密码！");
				return false;
			}
			if(newPwd.value == "") {
				alert("请输入新密码！");
				return false;
			}
			if(chePwd.value == "") {
				alert("请输入确定密码！");
				return false;
			}
			if(newPwd.value != chePwd.value) {
				alert("密码与确认密码不同!");
				return false;
			}
			if(newPwd.value.length < 6) {
				alert("新密码的长度应大于6！");
				return false;
			}
			return true;
		}
		/* 更新数据库表中用户的密码 */
		function updataPwd() {
			if(cheData()) { //调用cheData（）函数，如果为真，没有错误
				var xhr1 = new XMLHttpRequest();
				var oldPwd = document.getElementById("oldPwd"); //原密码
				var newPwd = document.getElementById("newPwd"); //新密码
				xhr1.open("POST", "back/cheDataBack.php", true);
				xhr1.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
				xhr1.send("oldPwd=" + oldPwd.value);
				xhr1.onreadystatechange = function() {
					if(xhr1.status == 200 && xhr1.readyState == 4) {
						var data1 = xhr1.responseText;
						data1 = JSON.parse(data1);
						console.log(data1);
						if(data1.length == 1) { //原密码与该用户数据库中的密码相等
							//							returnValue = 1;
							console.log(typeof data1);
							//							alert("原密码正确");
							var xhr2 = new XMLHttpRequest();
							xhr2.open("POST", "back/updatePwd.php", true);
							xhr2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
							xhr2.send("newPwd=" + newPwd.value);
							xhr2.onreadystatechange = function() {
								if(xhr2.status == 200 && xhr2.readyState == 4) {
									var data2 = xhr2.responseText;
									data2 = JSON.parse(data2);
									//									console.log(data2);
									if(data2) { //原密码与该用户数据库中的密码相等
										alert("修改密码成功！");
										window.location.href = "login.html";
									} else {
										alert("修改密码失败！");
										window.location.href = "geren.php";
									}
								}
							}
						} else {
							alert("原密码错误！");
							//							returnValue = 0;
						}
					}
				}
			}
		}

		/*判断修改信息是否填写*/
		function checkMas() {
			var name = document.getElementById('name');
			var tel1 = document.getElementById('tel1');
			var tel2 = document.getElementById('tel2');
			if(name.value == "") {
				alert("请输入姓名！");
				return false;
			}
			if(tel1.value == "") {
				alert("请输入电话1！");
				return false;
			} //判断电话1的格式
			else if(!(/^1[3456789]\d{9}$/.test(tel1.value))) {
				tel1.style.backgroundColor = "rgb(105,155,235)";
				alert("手机号码1格式错误，请重填！");
				return false;
			}
			/*当电话2不为空时，判断它的格式是否正确*/
			if(tel2.value != "") {
				if(!(/^1[3456789]\d{9}$/.test(tel2.value))) {
					alert("手机号码2格式错误，请重填！");
					return false;
				}
			}
			//当所有的条件满足，回调函数即可返回true
			if(name.value != "" && tel1.value != "" && (/^1[3456789]\d{9}$/.test(tel1.value))) {
				return true;
			}
		}

		/*更新数据库中用户的信息*/
		function updataMes() {
			if(checkMas()) { /*判断回调检测函数正确*/
				var xhr2 = new XMLHttpRequest();
				var name = document.getElementById("name"); //姓名
				var tel1 = document.getElementById("tel1"); //电话1
				var tel2 = document.getElementById("tel2"); //电话2
				xhr2.open("POST", "back/updateMes.php", true);
				xhr2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
				xhr2.send("name=" + name.value + "&tel1=" + tel1.value + "&tel2=" + tel2.value);
				xhr2.onreadystatechange = function() { //被引号引起来的是传到后台的变量
					if(xhr2.readyState == 4 && xhr2.status == 200) {
						var data = xhr2.responseText;
						data = JSON.parse(data);
						console.log(data);
						if(data == true) {
							alert("更改成功！");
							window.location.href = "geren.php";
						} else {
							alert("更改失败！请重试！");
						}
					}
				}
			}
		}
	</script>

	<script>
		// 显隐项目介绍详情
		$(function() {
			$('.dome').click(function() {
				if($('.main').is(':hidden')) {
					$('.main').show();
					$(this).text('点击收起');
				} else {
					$('.main').hide();
					$(this).text('更改信息');
				}
			});
		});
	</script>

	<body style="background-color: #f5f5f5;">
		<div align="center" style="margin: 0 auto; width: 800px; background-color: #fff;">
			<div id="link">
				<!-- 导航栏 -->
				<ul class="nav nav-tabs">
					<li role="presentation">
						<a href="index.html">购买</a>
					</li>
					<li role="presentation">
						<a href="order.html">订单详情</a>
					</li>
					<!--<li role="presentation">
						<a href="contact.html">联系我们</a>
					</li>-->
					<li role="presentation" class="active">
						<a href="geren.php">个人中心</a>
					</li>
					<div id="loginUser" style="float: right;padding-top: 10px">
						<!-- 登录，注册；或者欢迎你，注销 -->
					</div>
				</ul>
			</div>
			<!--<div class="head">-->
			<!--头像-->
			<!--<img src="https://how2j.cn/example.gif" class="img-thumbnail"><br>
			</div> 		<br><br>
			<div class="head">昵称</div>-->

			<div id="inpersonalOut">
				<!-- 在此div内默认内容是显示已登录时的内容，方便用ajax处理修改密码的功能‘s -->
				<div id="inpersonal">
					<!-- 如果未登录时，将此div隐藏，然后其外部div显示未登录时的内容 -->
					<ul id="myTab" class="breadcrumb">
						<li class="active">
							<a href="#jiben" data-toggle="tab">
								基本信息
							</a>
						</li>
						<li>
							<a href="#dizhi" data-toggle="tab">
								修改地址
							</a>
						</li>
						<li>
							<a href="#xiugai" data-toggle="tab">修改密码</a>
						</li>
					</ul>
					<div id="myTabContent" class="tab-content">
						<div class="tab-pane fade in active" id="jiben">
							<p>
								<div class="text-info">
									<h3>基本信息</h3>
								</div>
								<div class="outline" id="outContent">
									<!-- 显示用户的基本信息 -->
								</div>
								<div style="margin-top: 25px;">
									<div class='dome' style="border: 4px solid #009688;width: 70px;height: 30px;border-radius:5px ;background-color: #009688;color: #fff;">更改信息</div>
									<!--点击展开更改用户基本信息-->
									<div class="main" style="display:none;border: 1px solid rgba(204,204,204,0.7);background-color: rgba(236,245,255,0.95);width: 500px;height:350px;margin-top:10px;">
										<table class="table1">
											<tr>
												<td>昵称：</td>
												<td align="center">
													<div style="color: red;">注册后，即不可修改</div>
												</td>
											</tr>
											<tr>
												<td>姓名：</td>
												<td align="center">
													<div><input type="text" name="name" id="name" /></div>
												</td>
											</tr>

											<tr>
												<td>电话1：</td>
												<td align="center" id="attention">
													<div><input type="text" name="tel1" id="tel1" /></div>
												</td>
											</tr>
											<tr>
												<td>电话2：</td>
												<td align="center">
													<div><input type="text" name="tel2" id="tel2" /></div>
												</td>
											</tr>
										</table>

										<div style="margin-top: 25px;">
											<button class="btn btn-primary" type="button" onclick="updataMes();">更改</button></td>
											<button class="btn btn-primary" type="button"><a  href="javascript:location.reload();" style="color: #fff; text-decoration:none;">取消</a></button></td>
										</div>
									</div>
								</div>
							</p>
						</div>

						<div class="tab-pane fade active" id="dizhi">
							<p>
								<div class="text-info">
									<!--  tip2 -->
									<h3>修改送货地址</h3>
								</div>
								<div class="outline" style="width: 65%;">
									<?php
										$nickname = $_SESSION["userNickName"];
										$sql = mysqli_query($conn,"select * from tb_user where tb_user.nickname= '$nickname'");
										$info = mysqli_fetch_object($sql);
										$sql2 = mysqli_query($conn,"select * from tb_ss_address where tb_ss_address.nickname= '$nickname'");
										$info2 = mysqli_fetch_object($sql2);
									?>
										<form action="back/check_address.php" name="form1" id="form1" method="post">
											<table class="table1">
												<tr>
													<td>默认地址：</td>
													<td align="center">
														<div><input type="input" name="address1" id="address1" value=<?php echo $info->address; ?> /></div>
													</td>
												</tr>
												<tr>
													<td>其他地址1：</td>
													<td align="center">
														<div><input type="input" name="address2" id="address2" value="<?php if($info2){echo $info2->address_con1;} ?>" /></div>
													</td>
													<?php 
												if($info2 && $info2->address_con1){
													?>
													<td>
														<a href="back/update_address.php?id=1" style="text-decoration: none;">设为默认地址</a>
													</td>
													<?php
											}
											?>

												</tr>
												<tr>
													<td>其他地址2：</td>
													<td align="center">
														<div><input type="input" name="address3" id="address3" value="<?php if($info2){echo $info2->address_con2;} ?>" /></div>
													</td>
													<?php
												if($info2 && $info2->address_con2){
													?>
														<td>
															<a href="back/update_address.php?id=2" style="text-decoration: none;">设为默认地址</a>
														</td>
														<?php } ?>
												</tr>
												<tr>
													<td>其他地址3：</td>
													<td align="center">
														<div><input type="input" name="address4" id="address4" value="<?php if($info2){echo $info2->address_con3;} ?>" /></div>
													</td>
													<?php
												if($info2 && $info2->address_con3){
													?>
														<td>
															<a href="back/update_address.php?id=3" style="text-decoration: none;">设为默认地址</a>
														</td>
														<?php } ?>
												</tr>
												<tr>
													<td>其他地址4：</td>
													<td align="center">
														<div><input type="input" name="address5" id="address5" value="<?php if($info2){echo $info2->address_con4;} ?>" /></div>
													</td>
													<?php if($info2 && $info2->address_con4){ ?>
													<td>
														<a href="back/update_address.php?id=4" style="text-decoration: none;">设为默认地址</a>
													</td>
													<?php } ?>
												</tr>
											</table>
											<div style="margin-top: 25px;">
												<button class="btn btn-primary" type="submit" onclick="return updateAddress();">确定</button></td>
												<button class="btn btn-primary" type="button"><a  href="javascript:location.reload();" style="color: #fff; text-decoration:none;">取消</a></button></td>
											</div>
										</form>
								</div>
							</p>
						</div>
						<script>
							//		提交修改地址表单前的基本检查
							function updateAddress() {
								if(document.getElementById("address1").value == "") {
									alert("默认地址不允许为空！");
									document.getElementById("address1").focus();
									return false;
								}
								return true;
							}
						</script>
						<div class="tab-pane fade active" id="xiugai">
							<p>
								<div class="text-info">
									<!--  tip2 -->
									<h3>修改密码</h3>
								</div>
								<div class="outline">
									<table class="table1">
										<tr>
											<td>原密码：</td>
											<td align="center">
												<div><input type="password" name="oldPwd" id="oldPwd" /></div>
											</td>
										</tr>
										<tr>
											<td>新密码：</td>
											<td align="center">
												<div><input type="password" name="newPwd" id="newPwd" /></div>
											</td>
										</tr>
										<tr>
											<td>确定密码：</td>
											<td align="center">
												<div><input type="password" name="chePwd" id="chePwd" /></div>
											</td>
										</tr>
									</table>
									<div style="margin-top: 25px;">
										<button class="btn btn-primary" type="button" onclick="updataPwd();">确定</button></td>
										<button class="btn btn-primary" type="button"><a  href="javascript:location.reload();" style="color: #fff; text-decoration:none;">取消</a></button></td>
									</div>
								</div>
							</p>
						</div>
					</div>

				</div>
			</div>

		</div>
	</body>

	</html>