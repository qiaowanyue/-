<?php
//$conn=mysql_connect("localhost:3306","a0922095059","50322150")or die("数据库服务器连接错误".mysql_error());
$conn=mysqli_connect('localhost','a0922095059','50322150','a0922095059',3306);
//mysql_select_db("a0922095059",$conn) or die("数据库访问错误".mysql_error());
if(!$conn){
    die('Connect Error('.mysqli_connect_error().')'.mysqli_connect_error());
}
mysqli_query($conn,"set names utf8");
?>