<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>修改工人信息</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/addtzs.css" rel="stylesheet">
	<script>
		function checkDate(form){
			if(form.w_name.value=="")
			{
				alert("请输入姓名！");
				form.w_name.focus();
				return false;
			}
			if(form.w_mobile.value=="")
			{
				alert("请输入手机号码！");
				form.w_mobile.focus();
				return false;
			}else if(!(/^1[3456789]\d{9}$/.test(form.w_mobile.value)))
			{
				alert("手机号码有误，请重填！");
				form.w_mobile.focus();
				return false;
			}
			if(form.w_sex.value=="")
			{
				alert("请输入性别！");
				form.w_sex.focus();
				return false;
			}
			if(form.ticheng.value=="")
			{
				alert("请输入提成！");
				form.ticheng.focus();
				return false;
			}else if(!(/^[0-9]{1,}.?[0-9]{0,2}%{1}$/.test(form.ticheng.value)))
			{
				alert("提成输入有误，请重填！");
				form.ticheng.focus();
				return false;
			}
			if(form.jbgz.value=="")
			{
				alert("请输入基本工资！");
				form.jbgz.focus();
				return false;
			}else if(!(/^[0-9]*.?[0-9]{1,2}$/.test(form.jbgz.value)))
			{
				alert("基本工资只能是数字！小数点后最多两位");
				form.jbgz.focus();
				return false;
			}
			if(form.w_num.value=="")
			{
				alert("请输入桶数！");
				form.w_num.focus();
				return false;
			}else if(!(/^[0-9]*$/.test(form.w_num.value)))
			{
				alert("桶数只能是整数！");
				form.w_num.focus();
				return false;
			}
			
		}
	</script>
	<?php
		include("conn/conn.php");
		$s_id=$_GET["s_id"];	//取出工号
		$sql=mysqli_query($conn,"select * from tb_worker w JOIN tb_salary s ON w.worker=s.worker where s.s_id='$s_id'");
		$info=mysqli_fetch_object($sql);
		
	?>
	<body id="container">
		<p>
			<div class="text-info">
				<h3>修改工人信息</h3>
			</div>
		</p>
		<div class="outline">
		<!--将onSubmit写在form表单中代替onclik写在input中。防止表单的刷新-->
			<form name="form1" onSubmit="return checkDate(this)" method="post" action="back/changeWorker.php">
				<table align="center" style="margin-top: 10px;" border="1px" width="460px">
					<tr>
						<td>工号：</td>
						<td align="center">
							<input type="hidden" name="tzs" id="tzs" value="<?php echo $info->tzs;?>"/>
							<input readonly="readonly" value="<?php echo $info->worker;?>"type="text" class="form-control" name="worker" id="worker" style="border-color: #93BEE2;width: 270px;"/>
						</td>
					</tr>
					<tr>
						<td>姓名：</td>
						<td align="center">
							<input value="<?php echo $info->w_name;?>" type="text" class="form-control" name="w_name" id="w_name" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>手机号码：</td>
						<td align="center">
							<input value="<?php echo $info->w_mobile;?>" type="text" class="form-control" name="w_mobile" id="w_mobile" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>性别：</td>
						<td align="center">
							<input value="<?php echo $info->w_sex;?>" type="text" class="form-control" name="w_sex" id="w_sex" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>送水提成：</td>
						<td align="center">
							<input placeholder="15%" value="<?php echo $info->ticheng;?>" type="text" class="form-control" name="ticheng" id="ticheng" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>基本工资：</td>
						<td align="center">
							<input value="<?php echo $info->jbgz;?>" type="text" class="form-control" name="jbgz" id="jbgz" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>已送桶数/桶</td>
						<td align="center">
							<input value="<?php echo $info->w_num;?>" type="text" class="form-control" name="w_num" id="w_num" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
				</table>	
				<div style="margin-top: 20px;">
					<input type="submit" name="submit" id="Submit" value="修改" class="btn btn-primary"/>
					<button type="button" id="Submit2" class="btn btn-primary"><a href="javascript:history.back();" style="text-decoration: none;color: #fff;">取消</a></button>
				</div>
			</form>
		</div>
	</body>
</html>