<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>订单管理-编辑订单</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<script type="text/javascript">
	</script>
	<?php
		include("conn/conn.php");
//		$sql=mysqli_query($conn,"SELECT * FROM tb_order;");
//		$info=mysqli_fetch_object($sql);
	?>
	<body id="container">
		<ul id="myTab" class="breadcrumb">
			<li class="active">
				<a href="#dai" data-toggle="tab">待发货</a>
			</li>
			<li>
				<a href="#wei" data-toggle="tab">未收款</a>
			</li>
			<li>
				<a href="#yiw" data-toggle="tab">已完成</a>
			</li>
		</ul>
		<div id="myTabContent" class="tab-content" style="font-size: 12px;">
			<div class="tab-pane fade in active" id="dai">
				<p>
					<div class="text-info">
						<h3>待发货</h3>
					</div>
				</p>
				<?php
					//待发货催单的显示情况
					$sql0=mysqli_query($conn,"SELECT * FROM tb_order where status='0' order by create_time desc");
					$info0=mysqli_fetch_object($sql0);
					$remind_status=$info0->remind_status;
					if($info0==false){
		     			echo "<div algin='center' style='color: red;'>本站暂无\"待发货\"订单!</div>";    
					}else{
						
				?>
				<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
					<thead>
					    <th class="try1">订单号</th><!--订单id-->
					    <th class="try1">提交时间</th>
					    <th class="try1">总额/元</th>
					    <th class="try1">订单状态</th><!--状态，0:未发货，1：已发货，2：已完成，3：坏桶-->
					    <th class="try1">最新催单</th>
					    <th class="try1">操作</th>
				 	</thead>
				 	
				 	<tbody>
				 		<?php
				 			if($remind_status==1){
				 			do{
				 		?>
				 				<tr>
					        		<td><?php echo $info0->order_id;?></td>   
					        		<td><?php echo $info0->create_time;?></td>  
					        		<td><?php echo $info0->amount;?></td>
					        		<td><span class="bg-warning">未发货</span></td>
					        		<td><p style="color: darkred;" class="bg-danger"><?php echo $info0->remind_time;?></p></td>
					        		<td>
						        		<button type="button" class="buttoncss"><a style="text-decoration: none;" href="checkDaiOrder.php?order_id=<?php echo $info0->order_id;?>">查看</a></button>
							        	<button type="button"  class="buttoncss"><a style="text-decoration: none;" onclick="return checkTime(<?php echo $info0->create_time;?>);" href="giveWorker.php?order_id=<?php echo $info0->order_id;?>">派发</a></button>
						        		<button type="button"  class="buttoncss"><a style="text-decoration: none;" href="back/delOrder.php?order_id=<?php echo $info0->order_id;?>">删除</a></button>
					        		</td>
				    			 </tr>
				     	<?php
				 			}while($info0=mysqli_fetch_object($sql0));
				 		?>
				  	</tbody>
				</table>		
				
				<?php	
				}else if($remind_status==0){
				 			do{
				 		?>
				 				<tr>
					        		<td><?php echo $info0->order_id;?></td>   
					        		<td><?php echo $info0->create_time;?></td>  
					        		<td><?php echo $info0->amount;?></td>
					        		<td><span class="bg-warning">未发货</span></td>
					        		<td><p style="color: darkgreen;" class="bg-success">五</p></td>
					        		<td>
						        		<button type="button" class="buttoncss"><a style="text-decoration: none;" href="checkDaiOrder.php?order_id=<?php echo $info0->order_id;?>">查看</a></button>
							        	<button type="button"  class="buttoncss"><a style="text-decoration: none;" onclick="return checkTime(<?php echo $info0->create_time;?>);" href="giveWorker.php?order_id=<?php echo $info0->order_id;?>">派发</a></button>
						        		<button type="button"  class="buttoncss"><a style="text-decoration: none;" href="back/delOrder.php?order_id=<?php echo $info0->order_id;?>">删除</a></button>
					        		</td>
				    			 </tr>
				     	<?php
				 			}while($info0=mysqli_fetch_object($sql0));
				 		?>
				  	</tbody>
				</table>		
				<?php	
				} 
					}
				?>
				
			</div>
			<script>
				//a标签跳转之前执行，若为false，不跳转
				function checkTime(create_time)
				{
//					alert("jinru");
					$create_time=$_GET["create_time"];//取出提交时间
					$time1=strtotime($create_time);//化为时间戳，才能计算
					$time2=time();//点击派发的时间，此刻的时间
					$sub=cell(($time2-$time1)/(60*60*24*24));//相差多少分钟
					alert($sub);
					if($sub>30)//超过30分钟
					{
						var r = confirm("订单提交已超过30分钟！请联系用户后再发货!");
						if (r == true) {
//					    x = "您按了确认！";
						return true;
						}else {
//						alert("取消收款");
//					    x = "您按了取消！";
						return false;
					    }
					}
				}
			</script>
			
			
			
			
			<div class="tab-pane fade" id="wei">
				<p>
					<div class="text-info">
						<h3>已发货/未收款</h3>
					</div>
				</p>
				<?php
					//已发货和未付款的显示情况
					$sql1=mysqli_query($conn,"SELECT * FROM tb_chuli c JOIN tb_order o ON c.order_id=o.order_id where o.`status`='1' order by fahuotime desc");
					$info1=mysqli_fetch_object($sql1);
					
					if($info1==false){
		     			echo "<div algin='center' style='color: red;'>本站暂无\"已发货/未付款\"订单!</div>";    
					}else{
				?>
				<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
				  	<thead>
					    <th class="try1">订单号</th><!--订单id-->
					    <th class="try1">发货时间</th>
					    <th class="try1">总额/元</th>
					    <th class="try1">订单状态</th><!--状态，0:未发货，1：已发货，2：已完成，3：坏桶-->
					    <th class="try1">操作</th>
				  	</thead>
				  	<tbody>
				  		<?php
				 			do{
				 		?>
				 				<tr>
					        		<td><?php echo $info1->order_id;?></td>  
					        		<td><?php echo $info1->fahuotime;?></td>  
					        		<td id="amount"><?php echo $info1->amount;?></td>
					        		<td><sapn class="bg-success">未收款</sapn></td>
					        		<td>
						        		<button type="button" class="buttoncss"><a style="text-decoration: none;" href="checkWskOrder.php?order_id=<?php echo $info1->order_id;?>">查看</a></button>
							        	<button type="button"  class="buttoncss"><a style="text-decoration: none;" onclick="return checkAmount(<?php echo $info1->amount;?>);" href="back/checkShouk.php?order_id=<?php echo $info1->order_id;?>">收款</a></button>
					        		</td>
				    			 </tr>
				     	<?php
				 			}while($info1=mysqli_fetch_object($sql1));
				 		?>
				  	</tbody>
				</table>
				<?php	
					}
				?>
			</div>
			<script>
				//a标签跳转之前执行，若为false，不跳转
				function checkAmount(amount)
				{
					var r = confirm("确定收款总金额为："+amount+"元");
					if (r == true) {
//					    x = "您按了确认！";
						return true;
					} else {
						alert("取消收款");
//					    x = "您按了取消！";
						return false;
					}
				}
			</script>
			
			
			
			
			<div class="tab-pane fade" id="yiw">
				<p>
					<div class="text-info">
						<h3>已完成</h3>
					</div>
				</p>
				<?php
					//已完成的显示情况
					$sql2=mysqli_query($conn,"SELECT * FROM tb_chuli c JOIN tb_order o ON c.order_id=o.order_id where o.`status`='2' or o.`status`='3' order by shouktime desc");
					$info2=mysqli_fetch_object($sql2);
					
					if($info2==false){
		     			echo "<div algin='center' style='color: red;'>本站暂无\"已完成\"订单!</div>";    
					}else{
				?>
				<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
				  	<thead>
					    <th class="try1">订单号</th><!--订单id-->
					    <th class="try1">时间</th>
					    <th class="try1">总额/元</th>
					    <th class="try1">工号</th>
					    <th class="try1">订单状态</th><!--状态，0:未发货，1：已发货，2：已完成，3：坏桶-->
					    <th class="try1">操作</th>
				  	</thead>
				  	<tbody>
				  		<?php
				 			do{
				 		?>
				  		<tr>
					        <td><?php echo $info2->order_id;?></td>    
					        <td><?php echo $info2->shouktime;?></td>  
					        <td><?php echo $info2->amount;?></td>
					        <td><?php echo $info2->worker;?></td>
					        <!--<td><sapn class="bg-success">已完成</sapn></td>-->
					        <?php
					        	if($info2->status==3)//已完成
					        	{
					        ?>		<td><sapn class='bg-danger'>存在坏桶</sapn></td>
					        		<td>
					        			<button type="button" class="buttoncss"><a style="text-decoration: none;" href="checkBadTzs.php?order_id=<?php echo $info2->order_id;?>">查看</a></button>
						        		<button type="button" class="buttoncss"><a style="text-decoration: none;" href="giveBadTzsWorker.php?order_id=<?php echo $info2->order_id;?>">坏桶</a></button>
					        		</td>
					        <?php		
					        }
					        	else if($info2->status==2)//坏桶
					        	{
					        ?>
					        		<td><sapn class='bg-primary'>已完成</sapn></td>
					        		<td>
						        		<button type="button" class="buttoncss"><a style="text-decoration: none;" href="checkYiwOrder.php?order_id=<?php echo $info2->order_id;?>">查看</a></button>
					        			<button type="button" class="buttoncss"><a style="text-decoration: none;" href="giveBadTzsWorker.php?order_id=<?php echo $info2->order_id;?>">坏桶</a></button>
					        		</td>
					        <?php		
					        	}
					        ?>
					       
				     	</tr>
				     	<?php
				 			}while($info2=mysqli_fetch_object($sql2));
				 		?>
				  	</tbody>
				  	</table>
				<?php	
					}
				?>
			</div>
		</div>
	</body>
</html>
