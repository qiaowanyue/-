<?php
	header ( "Content-type: text/html; charset=utf-8" );
	session_start();
	if(!isset($_SESSION['adminzhanghao'])){
		echo "<script>alert('未登录！请登录！');window.location.href='index.html';</script>";
		exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>桶装水配送系统</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/default.css" rel="stylesheet" />
	
	<script>
		/* 检测工人工资表 */
		window.onload = function(){
			var xhr = new XMLHttpRequest();
			xhr.open("POST", "back/checkSalary.php", true);
			xhr.send();
			xhr.onreadystatechange = function() {
				if(xhr.status == 200 && xhr.readyState == 4) {
					var data = xhr.responseText;
					try{
						data = JSON.parse(data);
					}catch(e){
					//	data = JSON.parse(data);
					}
//					console.log(data);
					if(!data) { 
						alert("系统检测失败！请重试！");
					}
				}
			}
		}
		
	</script>
	
	<body style="background-color: #f5f5f5;">
		<div id="container">
			<div class="imgCenter">
				<!--banner-->
				<h2 class="text-info bannerFont">桶装水配送后台系统</h2>
				<div style="text-align: right; margin: 0px 40px 0px 0px;"><a style="text-decoration: none;" href="back/logout.php">注&nbsp;销</a></div>
			</div>
			<table>
				<tr>
					<td width="212" height="220" valign="top">
						<div align="center">
							<!--iframe 元素会创建包含另外一个文档的内联框架（即行内框架）。-->
							<IFRAME frameBorder=1 id=left name=left src="left.html" style="HEIGHT: 850px; VISIBILITY: inherit; WIDTH: 212px; Z-INDEX: 2"> </IFRAME>
						</div>
					</td>
					<td width="578" bgcolor="#FFFFFF" id="mn">
						<div align="center"><!--src="lookdd.php" !!!!!!记得设置默认的未查看订单-->
							<IFRAME frameBorder=0 id=main name=main scrolling=no  src="editOrder.php" style="HEIGHT: 1000px; VISIBILITY: inherit; WIDTH: 578px; Z-INDEX: 1"> </IFRAME>
						</div>
					</td>
				</tr>
			</table>
		</div>
	</body>

</html>