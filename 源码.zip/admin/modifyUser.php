<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>修改用户信息</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/addtzs.css" rel="stylesheet">
	<script>
		function checkDate(form){
			if(form.name.value=="")
			{
				alert("姓名不能为空!");
				form.name.focus();
				return false;
			}
			if(form.address.value=="")
			{
				alert("送货地址不能为空!");
				form.address.focus();
				return false;
			}
			if(form.mobile1.value=="")
			{
				alert("电话1不能为空！");
				form.mobile1.focus();
				return false;
			}else if(!(/^1[3456789]\d{9}$/.test(form.mobile1.value)))
			{
				alert("电话1有误，请重填！");
				form.mobile1.focus();
				return false;
			}
			if(!(/^1[3456789]\d{9}$/.test(form.mobile2.value)) && form.mobile2.value!="")
			{
				alert("电话2有误，请重填！");
				form.mobile2.focus();
				return false;
			}
			
		}
	</script>
	<?php
		include("conn/conn.php");
		$nickname=$_GET["nickname"];	//取出昵称
		$sql=mysqli_query($conn,"select * from tb_user where nickname='$nickname'");
		$info=mysqli_fetch_object($sql);
	?>
	<body id="container">
		<p>
			<div class="text-info">
				<h3>修改用户信息</h3>
			</div>
		</p>
		<div class="outline">
		<!--将onSubmit写在form表单中代替onclik写在input中。防止表单的刷新-->
			<form name="form1" onSubmit="return checkDate(this)" method="post" action="back/changeUser.php">
				<table align="center" style="margin-top: 10px;" border="1px" width="460px">
					<tr>
						<td>昵称：</td>
						<td align="center">
							<input value="<?php echo $info->nickname;?>" title="用户昵称不能修改" readonly="readonly" type="text" class="form-control" name="nickname" id="nickname" style="border-color: #93BEE2;width: 270px;"/>
						</td>
					</tr>
					<tr>
						<td>姓名：</td>
						<td align="center">
							<input value="<?php echo $info->name;?>" type="text" class="form-control" name="name" id="name" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>送水地址：</td>
						<td align="center">
							<input value="<?php echo $info->address;?>" type="text" class="form-control" name="address" id="address" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>电话1：</td>
						<td align="center">
							<input value="<?php echo $info->u_mobile1;?>" type="text" class="form-control" name="mobile1" id="mobile1" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>电话2：</td>
						<td align="center">
							<input value="<?php echo $info->u_mobile2;?>" type="text" class="form-control" name="mobile2" id="mobile2" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
				</table>	
				<div style="margin-top: 20px;">
					<input type="submit" name="submit" id="Submit" value="修改" class="btn btn-primary"/>
					<button type="button" id="Submit2" class="btn btn-primary"><a href="javascript:history.back();" style="text-decoration: none;color: #fff;">返回</a></button>
				</div>
			</form>
		</div>
	</body>
</html>
