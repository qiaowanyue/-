<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>派发订单</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<script type="text/javascript">
		/* 判断单选框是否被选中 */
		function checkChoice(form)
		{
//			alert(form.order_id.value);
			var radioSelete = "Nothing";
			var selectedValue;
			for(var i=0;i<form.worker.length;i++)
			{
				if(form.worker[i].checked)//被选中
				{
					radioSelete = "seleted";
					selectedValue = form.worker.value;
				}
			}
			if(radioSelete == "Nothing")
			{
				alert("请选择一个工人！");
				return false;
			}
			else
			{
				alert("您选择的工号是:"+selectedValue);
				return true;	
			}
		}
	</script>
	<?php
		include("conn/conn.php");
		$time = date("Y-m");
		$order_id=$_GET["order_id"];//取出订单id号
		$sql=mysqli_query($conn,"select * from tb_worker w JOIN tb_salary s ON w.worker=s.worker where status = '0' and time LIKE '$time%';");
		$info=mysqli_fetch_object($sql);
		if($info==false){
		    echo "<div algin='center' style='color: red;'>本站暂无工人信息!</div>";    
		}else{
	?>
<body id="container">
	<p>
		<div class="text-info">
			<h3>指定工人</h3>
		</div>
	</p>
	<form name="form1" method="post" onsubmit="return checkChoice(this);" action="back/chuli.php">
	<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
		<thead>
		    <th class="try1">工号</th>
		    <th class="try1">姓名</th>
		    <th class="try1">手机号码</th>
		    <th class="try1">操作</th>
	 	</thead>
	 	<tbody>
	 		<?php
	 			do{
	 		?>
		 		<tr>
		 			<td><?php echo $info->worker;?></td>
		 			<td><?php echo $info->w_name;?></td>
		 			<td><?php echo $info->w_mobile;?></td>
		 			<!--<input TYPE="button" name="edit" value="编辑" onclick="return formSubmit('edit');">-->
		 			<td><input type="radio" name="worker" value="<?php echo $info->worker;?>" /><input type="hidden" name="s_id" id="s_id" value="<?php echo $info->s_id;?>"/></td>
		 		</tr>
	 		<?php		
	 			}while($info=mysqli_fetch_object($sql));
	 		?>
	 	</tbody>
	</table>
		<div style="margin-top: 20px;">
			<input type="hidden" name="order_id" id="order_id" value="<?php echo $order_id;?>"/>
			
			<input type="submit" name="Submit" id="Submit"  value="派发"/ class="btn btn-primary"/>
		<button type="button" id="Submit2" class="btn btn-primary"><a href="javascript:history.back();" style="text-decoration: none;color: #fff;">返回</a></button>
			
		</div>
	</form>
	<?php
	}
	?>
</body>
</html>