<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>添加工人信息</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../js/jquery.form.min.js" type="text/javascript"></script>
	<link href="css/addtzs.css" rel="stylesheet">
	<script type="text/javascript">
			function chekData(form) {
			if(form.worker.value=="")
			{
				alert("请输入工号！");
				form.worker.focus();
				return false;
			}else if(/^\s*$/.test(form.worker.value)){
				alert("工号不能全为空格！");
				form.worker.focus();
				return false;
			}else if(!(/^[0-9]{1,}$/.test(form.worker.value))){
				alert("工号只能是数字，请重输！");
				form.worker.focus();
				return false;
			}
			
			if(form.w_mobile.value=="")
			{
				alert("请输入电话号码！");
				form.w_mobile.focus();
				return false;
			}else if(!(/^1[3456789]\d{9}$/.test(form.w_mobile.value))){
				alert("电话格式错误，请重新输入！");
				form.w_mobile.focus();
				return false;
			}
			if(form.ticheng.value=="")
			{
				alert("请输入送水提成！");
				form.ticheng.focus();
				return false;
			}
			if(form.jbgz.value=="")
			{
				alert("请输入基本工资！");
				form.jbgz.focus();
				return false;
			}
		}
	</script>

	<body>
		<div id="container">
			<div class="text-info">
				<h3>添加工人信息</h3></div>
			<div class="outline">
				<form  name="form1" method="post" onSubmit="return chekData(this);" action="back/addWorker.php" enctype="multipart/form-data">
				<table align="center" style="margin-top: 10px;" border="1px" width="460px">
					<tr>
						<td>工号：</td>
						<td align="center">
							<input type="text" class="form-control" name="worker" id="worker" style="border-color: #93BEE2;width: 270px; "/><!--padding: 4px 0px;-->
						</td>
					</tr>
					<tr>
						<td>姓名：</td>
						<td align="center">
							<input type="text" class="form-control" name="w_name" id="w_name" style="border-color: #93BEE2;width: 270px; "/>
						</td>

					</tr>
					<tr>
						<td>手机号码：</td>
						<td align="center">
							<input type="text" class="form-control" name="w_mobile" id="w_mobile" style="border-color: #93BEE2;width: 270px;" /><!--placeholder占位符-->
						</td>
					</tr>
					<tr>
						<td>性别：</td>
						<td align="center">
							<!--<input placeholder="男/女" type="text" class="form-control" name="w_sex" id="w_sex" style="border-color: #93BEE2;width: 270px; "placeholder="15L"/>-->
							<div align="left" style="margin-left: 50px;">
	         					<select name="w_sex" class="inputcss" >
	           					<option selected value='男'>男</option>
	            				<option value='女'>女</option>
	          					</select> 
          					</div>
						</td>
					</tr>
					<tr>
						<td>送水提成：</td>
						<td align="center">
							<input type="text" class="form-control" name="ticheng" id="ticheng" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>基本工资：</td>
						<td align="center">
							<input type="text" class="form-control" name="jbgz" id="jbgz" style="border-color: #93BEE2;width: 270px;" />
						</td>
					</tr>
					
					<!--<tr>
						<td>已送桶数：</td>
						<td align="center">
							<input placeholder="12桶" type="text" class="form-control" name="yisong" id="yisong" style="border-color: #93BEE2;width: 270px;"  />
						</td>
					</tr>-->
				</table>
				<div style="margin-top: 20px;">
					<input type="submit" name="Submit" id="Submit"  value="添加"/ class="btn btn-primary"/>
					<button class="btn btn-primary" type="button"><a href="javascript:location.reload();"style="color: #fff; text-decoration:none;">重置</a></button>
				</div>
				</form>
			</div>
		</div>
		<!--添加-->
	</body>

</html>