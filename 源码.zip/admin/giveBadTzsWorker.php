<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>坏桶再次派发订单</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<script type="text/javascript">
		window.onload = function(){
			var arrPlus = document.getElementsByClassName("plus");//取加号的对象
			for(var i=0;i<arrPlus.length;i++){//遍历循环
				arrPlus[i].onclick = function(){//当加号被点击
					//取被点击节点的兄弟节点的方法，为父节点的子节点
					var valueNum = this.parentNode.getElementsByClassName('menunum')['0'];//取出文本框对象
					var o_num = this.parentNode.getElementsByClassName('o_num')['0'].value;//取出文本框对象
//					alert(o_num);alert(valueNum.value);
					if(parseInt(valueNum.value) < parseInt(o_num)){
						valueNum.value = parseInt(valueNum.value) + 1;
					}else{
						alert("数值已最大");
						return false;
					}
				}
			}
			//减
			var arrMinus = document.getElementsByClassName("minus");//取减号的对象
			for(var i=0;i<arrMinus.length;i++){//遍历循环
				arrMinus[i].onclick = function(){//当减号被点击
					var valueNum = this.parentNode.getElementsByClassName('menunum')['0'];
					if(valueNum.value == 0){
						alert("数值已最小");
						return false;//让程序停止运行
					}
					else{
						valueNum.value = parseInt(valueNum.value) - 1;
					}
				}
			}
		}
		/* 判断单选框是否被选中 */
		function checkChoice(form)
		{
//			alert(form.order_id.value);
			var radioSelete = "Nothing";
			var selectedValue;
			for(var i=0;i<form.worker.length;i++)
			{
				if(form.worker[i].checked)//被选中
				{
					radioSelete = "seleted";
					selectedValue = form.worker.value;
				}
			}
			if(radioSelete == "Nothing")
			{
				alert("请选择一位工人！");
				return false;
			}
			else
			{
				alert("您选择的工号是:"+selectedValue);
				return true;	
			}
		}
	</script>
	<?php
		session_start();
		$time = date("Y-m");
		include("conn/conn.php");
		$order_id=$_GET["order_id"];//取出订单id号
		$sql=mysqli_query($conn,"select * from tb_worker w JOIN tb_salary s ON w.worker=s.worker where status = '0' and time LIKE '$time%'");
		$info=mysqli_fetch_object($sql);
		if($info==false){
		    echo "<div algin='center' style='color: red;'>本站暂无工人信息!</div>";    
		}else{
	?>
<body id="container">
	<!--从已完成的坏桶按钮点击进来的，订单的状态一定为已完成的时候。通过选择工人以及桶装水后，跳转到后台处理-->
	<p>
		<div class="text-info">
			<h3>指定工人</h3>
		</div>
	</p>
	<form name="form1" method="post" onsubmit="return checkChoice(this);" action="back/addBadTzs.php">
	<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
		<thead>
		    <th class="try1">工号</th>
		    <th class="try1">姓名</th>
		    <th class="try1">手机号码</th>
		    <th class="try1">操作</th>
	 	</thead>
	 	<tbody>
	 		<?php
	 			do{
	 		?>
		 		<tr>
		 			<td><?php echo $info->worker;?></td>
		 			<td><?php echo $info->w_name;?></td>
		 			<td><?php echo $info->w_mobile;?></td>
		 			<td><input type="radio" name="worker" value="<?php echo $info->worker;?>" /><input type="hidden" name="s_id" id="s_id" value="<?php echo $info->s_id;?>"/></td>
		 		</tr>
	 		<?php		
	 			}while($info=mysqli_fetch_object($sql));
	 		?>
	 	</tbody>
	</table>
	 
	 
	<p>
		<div class="text-info">
			<h3>指定坏桶</h3>
		</div>
	</p>
	<table   class="table table-hover outline" align="center">
	<!--订单中商品信息-->
		<thead>
		    <th class="try1">商品品牌</th>
		    <th class="try1">规格</th>
		    <th class="try1">购买数量</th>
		    <th class="try1">坏桶数量</th>
	 	</thead>
	 	<tbody>
	 	<?php
			$sql2=mysqli_query($conn,"SELECT * from tb_order_details d JOIN tb_tzs t ON d.tzs=t.tzs where order_id='$order_id'");
			$info2=mysqli_fetch_object($sql2);//取出该订单的订单详细中的商品信息
			do{
		?>
			<tr>
		 	<td><?php echo $info2->brand;?></td>
		 	<td><?php echo $info2->guige;?></td>
		 	<td><?php echo $info2->o_num;?></td>
		 	<td>
				<span class="plus" style="cursor:pointer"><!--style="cursor:pointer"鼠标变为手指-->
					＋
				</span>
				<?php
					//计算出目前坏桶的最大数目=全部-已是坏桶数目
					if($info2->bad_num!=NULL)
					{
						$max_num=($info2->o_num)-($info2->bad_num);
					}else{
						$max_num=$info2->o_num;
					}
					
				?>
				<input type="hidden"  class="o_num" name="o_num<?php echo $info2->tzs;?>" id="o_num<?php echo $info2->tzs;?>" value="<?php echo $max_num;?>"/><!--方便js获取商品购买数量，判断坏桶的最大数目-->
				<input style="width: 30px;" class="span1 menunum" type="text" name="<?php echo $info2->tzs;?>" id="<?php echo $info2->tzs;?>" value="0" />
				<span class="minus" style="cursor:pointer">
					—
				</span>
			</td>
			</tr>
		<?php
			}while($info2=mysqli_fetch_object($sql2));
		?>
	 	</tbody>
	<table>
		<div style="margin-top: 20px;">
			<input type="hidden" name="order_id" id="order_id" value="<?php echo $order_id;?>"/><!--隐藏order_id在input中，方便将order_id给后台-->
			<input type="submit" name="Submit" id="Submit"  value="确定"/ class="btn btn-primary"/>
		<button type="button" id="Submit2" class="btn btn-primary"><a href="editOrder.php" style="text-decoration: none;color: #fff;">返回</a></button>
			
		</div>
	</form>
	<?php
	}
	?>
</body>
</html>