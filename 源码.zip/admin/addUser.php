<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>用户注册</title>
</head>
<script src="../js/jquery.min.js" type="text/javascript"></script>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<link href="css/addUser.css" rel="stylesheet">
<script>
//    console.log(attention[0].value);
    var attention=document.getElementsByClassName("big");	/* 全局数组  */
    function checkNickName(){       /* 判断昵称是否输入 */
        var nickname1=document.getElementById("nickname").value;
        if(nickname1==""){
            nickname.style.backgroundColor="rgb(105,155,235)";	
            attention[0].style.color = "red";
            attention[0].innerHTML="请输入昵称！";		<!--提示显示-->
            return false;
        }else{
            var xhr = new XMLHttpRequest();
        	xhr.open("POST","../back/checkNickName.php",true);
        	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
        	xhr.send("nickname=" + nickname1);
        	xhr.onreadystatechange = function(){
        		if(xhr.readyState==4 && xhr.status==200){
        			var data = xhr.responseText;
        			data = JSON.parse(data);
//      			console.log(data);
        			if(data.length==1){
        				nickname.style.backgroundColor="rgb(105,155,235)";	
            			attention[0].style.color = "red";
          				attention[0].innerHTML="该昵称已被注册！";
          				return false;
        			}else{
        				nickname.style.backgroundColor="#FFF";
            			attention[0].style.color = "rgb(49,122,123)";
            			attention[0].innerHTML="√";
        			}
        		}
        	}
        }
    }

    function checkName(){       /* 判断姓名是否输入 */
        var name1=document.getElementById("_name").value;
//      console.log(name1);
        if(name1==""){
            _name.style.backgroundColor="rgb(105,155,235)";
            attention[1].style.color = "red";
            attention[1].innerHTML="请输入姓名！";
            return false;
        }
        else{
            _name.style.backgroundColor="#FFF";
            attention[1].style.color = "rgb(49,122,123)";
            attention[1].innerHTML="√";
        }
    }
function checkAddress(){        /* 判断送货地址是否输入 */
    var address1=document.getElementById("address").value;
    if(address1==""){
        address.style.backgroundColor="rgb(105,155,235)";
        attention[2].style.color = "red";
        attention[2].innerHTML="请输入送货地址！";
        return false;
    }
    else{
        address.style.backgroundColor="#FFF";
        attention[2].style.color = "rgb(49,122,123)";
        attention[2].innerHTML="√";
    }
}
function checkMobile1(){        /* 判断电话1是否输入 */
    var mobile=document.getElementById("mobile1").value;
    if(mobile==""){
        mobile1.style.backgroundColor="rgb(105,155,235)";
        attention[3].style.color = "red";
        attention[3].innerHTML="至少输入电话一！";
        return false;
    }
    else if(!(/^1[3456789]\d{9}$/.test(mobile))){
       		mobile1.style.backgroundColor="rgb(105,155,235)";
        	attention[3].style.color = "red";
        	attention[3].innerHTML="手机号码有误，请重填！";
        	return false;
       }else{
	       	var xhr = new XMLHttpRequest();
	    	xhr.open("POST","../back/checkMobile.php",true);
	    	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
	    	xhr.send("mobile=" + mobile);
	    	xhr.onreadystatechange = function(){
	    		if(xhr.readyState==4 && xhr.status==200){
	    			var data = xhr.responseText;
//	    			console.log(typeof data);
	    			data = JSON.parse(data);
//	      			console.log(data);
	    			if(data.length==1){
	    				mobile1.style.backgroundColor="rgb(105,155,235)";	
	        			attention[3].style.color = "red";
	      				attention[3].innerHTML="该电话号码已被注册！";
	      				return false;
	    			}else{
	    				mobile1.style.backgroundColor="#FFF";
				        attention[3].style.color = "rgb(49,122,123)";
				        attention[3].innerHTML="√";
	    			}
	    		}
	    	}
       	}
}
function checkMobile2(){
    var mobile=document.getElementById("mobile2").value;
	if(mobile!=""){	//电话2不为空
		if(/^1[3456789]\d{9}$/.test(mobile)	)//电话2格式正确
		{
       		var xhr = new XMLHttpRequest();
	    	xhr.open("POST","../back/checkMobile.php",true);
	    	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
	    	xhr.send("mobile=" + mobile);
	    	xhr.onreadystatechange = function(){
    		if(xhr.readyState==4 && xhr.status==200){
    			var data = xhr.responseText;
//  			console.log(typeof data);
    			data = JSON.parse(data);
//    			console.log(data);
    			if(data.length==1){
    				mobile2.style.backgroundColor="rgb(105,155,235)";	
        			attention[4].style.color = "red";
      				attention[4].innerHTML="该电话号码已被注册！";
      				return false;
    			}else{
    				mobile2.style.backgroundColor="#FFF";
        			attention[4].style.color = "rgb(49,122,123)";
        			attention[4].innerHTML="√";
    			}
    		}
	      }
	    }
	    else{
       		mobile2.style.backgroundColor="rgb(105,155,235)";
        	attention[4].style.color = "red";
        	attention[4].innerHTML="手机号码有误，请重填！";
        	return false;
      }
     }
  }



	/* ajax前后端分离 开始    */
	function submitUserInfo(){
//		console.log(checkCheckPwd()==undefined);		确定函数是否正确
		if(checkNickName()==undefined && checkName()==undefined && checkAddress()==undefined && checkMobile1()==undefined && checkMobile2()==undefined)
		{
			var nickname1=document.getElementById("nickname").value;
       		var name1=document.getElementById("_name").value;
	    	var address1=document.getElementById("address").value;	
    		var mobile1=document.getElementById("mobile1").value;
    		var mobile2=document.getElementById("mobile2").value;
			var xhr = new XMLHttpRequest();
			xhr.open("POST","back/addUser.php",true);
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
			xhr.send("nickname=" + nickname1  + "&name=" + name1 + "&address=" + address1 + "&mobile1=" + mobile1 + "&mobile2=" + mobile2 );
			xhr.onreadystatechange=function(){
				//被引号引起来的是传到后台的变量
				if(xhr.readyState==4 && xhr.status==200){
					var data = xhr.responseText;
					data = JSON.parse(data);
//					console.log(data);
					if(data==true){
						alert("添加成功！");
						window.location.href="editUser.php";
					}else{
						alert("添加失败！请重试！");
					}
				}
			}
		}
		else{
			alert("提交失败！请按照提醒填写信息！");
		}
	}
	/* ajax前后端分离 结束*/
	
</script>
<body id="container">
    <div align="center" style="margin: 0px auto; width: 640px;">
        <div id="form1" style="margin: 20px auto;">
            <h2 class="text-info">添加线下用户信息</h2><!--#31708f-->
            <br/>
            <!--<div style="width: 120px;border: 1px solid red;height:150px; text-align: left; margin-right: 200px" > ddd </div>-->
            <div class="inputwidth" > <!--输入昵称-->
                <div  style="display: inline-block;" class="text-muted"><span>昵<text  class="invisible">帮助</text>称：</span></div>
                <input type="text" class="form-control"  name="nickname"  id="nickname" onblur="checkNickName();" style="width:270px;display: inline-block;">
                <div class="big">*</div><!--提示显示区域-->
            </div>
            <div class="inputwidth" > <!--输入姓名-->
                <div  style="display: inline-block;" class="text-muted"><span>姓<text  class="invisible">帮助</text>名：</span></div>
                <input type="text" class="form-control"  name="_name"  id="_name" onblur="checkName();" style="width:270px;display: inline-block;">
                <div class="big">*</div>
            </div>
            <div class="inputwidth" > <!--输入送货地址-->
                <div  style="display: inline-block;" class="text-muted"><span>送货地址：</span></div>
                <input type="text" class="form-control"  name="address"  id="address" onblur="checkAddress();" style="width:270px;display: inline-block;">
                <div class="big">*</div>
            </div>
            <div class="inputwidth" > <!--输入电话1-->
                <div  style="display: inline-block;" class="text-muted"><span>电话<text  class="invisible">分</text>一：</span></div>
                	<input value="<?php if(!(empty($_GET["mobile"]))){echo $_GET["mobile"];}?>" type="text" class="form-control"  name="mobile1"  id="mobile1" onblur="checkMobile1();" style="width:270px;display: inline-block;">
                <div class="big">*</div>
            </div>
            <div class="inputwidth" > <!--输入电话2-->
                <div  style="display: inline-block;" class="text-muted"><span>电话<text  class="invisible">分</text>二：</span></div>
                <input type="text" class="form-control"  name="mobile2"  id="mobile2" onblur="checkMobile2();" style="width:270px;display: inline-block;">
                <div class="big">*</div>
            </div>
            <button class="btn btn-primary mybtn" onclick="submitUserInfo();">确定</button>
            <button type="button" class="btn btn-primary mybtn"><!--页面刷新-->
            	<a href="javascript:location.reload();" style="color: #fff; text-decoration:none;">重置</a>
            </button>
        </div>
    </div>
</body>
</html>