<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>用户管理</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<script>
		function check(form){
			//form是形参
//			if(form.txt_keyword.value==""){
//				alert("请输入查询关键字！");
//				form.txt_keyword.focus();
//				return false;
//			}
		}
	</script>
	<body id="container">
		<div class="text-info">
			<h3>用户管理</h3>
		</div>
		<div class="outline">
			<div>
				<form name="form1" method="post" action="">
					<input placeholder="请搜索用户昵称或电话" type="text" class="form-control"  name="txt_keyword"  id="txt_keyword" style="width:170px;display: inline;margin:20px 20px 20px 0px;" />
					<input type="submit" class="buttoncss btn btn-primary" name="Submit" id="Submit" value="查询" onClick="return check(form1)" />
				</form>
			</div>
		</div>
		<table class="table table-hover outline" align="center" style="margin-top: 10px;">
			<thead>
				<th class="try1">昵称</th>
				<th class="try1">姓名</th>
				<th class="try1">送水地址</th>
				<th class="try1">电话1</th>
				<th class="try1">电话2</th>
				<th class="try1">类型</th>
				<th class="try1">操作</th>
			</thead>
			<tbody>
				<?php
					//判断数据库中有无用户
					include("conn/conn.php");
		//			$sql=mysqli_query($conn,"select count(*) as total from tb_user");
		//			$info = mysqli_fetch_object($sql);
		//			$total=$info->total;
		//			if($total==0){	//没有用户
		//				echo "本站暂无用户注册！";
		//			}
				$sql = mysqli_query($conn,"select * from tb_user");
				$row = mysqli_fetch_object($sql);
				if(isset($_POST['Submit'])){
		        	$keyword = $_POST['txt_keyword'];
		        	$sql = mysqli_query($conn,"select * from tb_user where nickname like '%".trim($keyword)."%' or u_mobile1 like '%".trim($keyword)."%' or u_mobile2 like '%".trim($keyword)."%'");
		        	//$sql中只包括了符合条件的公告内容
		        	$row = mysqli_fetch_object($sql);
		        }
		        if(!$row){
		        	echo "<font color='red'>您搜索的信息不存在，请使用类似的关键字进行检索！</font>";
		        }else{
				?>
				<?php
					//循环结构，开始
					do{
				?>
				<tr>
					<!--循环显示的区域-->
					<td><?php echo $row->nickname;?></td>
					<td><?php echo $row->name;?></td>
					<td><?php echo $row->address;?></td>
					<td><?php echo $row->u_mobile1;?></td>
					<td><?php echo $row->u_mobile2;?></td>
					<?php
						if($row->u_pwd=="NULL"){
							echo "<td><span class='bg-success'>线下</span></td>";
						}else{
							echo "<td><span class='bg-info'>线上</span></td>";
						}
					?>												
					<!--线上是网络，线下是现实-->
					<td>
						<button type="button" class="buttoncss"><a href="modifyUser.php?nickname=<?php echo $row->nickname;?>">修改</a></button>
						<button type="button" class="buttoncss"><a style="text-decoration: none;" href="back/delUser.php?nickname=<?php echo $row->nickname;?>">删除</a></button>
					</td>
				</tr>
				<?php
					//循环结束
				}while($row=mysqli_fetch_object($sql));
				?>
			</tbody>
		</table>
		<?php
			//else有用户的情况结束
		}
		?>
	</body>
</html>
