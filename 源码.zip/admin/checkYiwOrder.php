<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>查看已完成订单</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<?php
		include("conn/conn.php");
		$order_id=$_GET["order_id"];
		$sql=mysqli_query($conn,"SELECT * FROM tb_order_details d JOIN tb_order o ON d.order_id=o.order_id WHERE o.order_id='$order_id' ORDER BY o.order_id;");
		$info=mysqli_fetch_object($sql);
		$sql4=mysqli_query($conn,"select * from tb_chuli c join tb_worker w on c.worker = w.worker  where order_id = '$order_id'");
		$info4=mysqli_fetch_object($sql4);
		
		//能跳转到此界面，说明订单一定是存在的，所以不用再判断查询结果集是否为空
	?>
<body id="container">
	<div class="text-info">
		<h3>查看订单</h3>
	</div>
	<!--订单详细信息-->
	<div class="outline">
		<table class="table" align="center" style="margin-top: 10px;">
			<tr>
				<div class="text-info">
					<h4>订单</h4>
				</div>
			</tr>
			<thead>
				<th class="try1">订单号</th>
				<th class="try1">订单状态</th><!--o:未发货，1：已发货，2：已完成-->
				<th class="try1">总额/元</th>
			</thead>
			<tbody>
					<tr>
						<td><?php echo $info->order_id;?></td>
						<td><span class="bg-primary">已完成</span></td>
						<td><?php echo $info->amount;?></td>
					</tr>
			</tbody>
			<tbody>
				<th class="try1">提交时间</th>
				<th class="try1">发货时间</th>
				<th class="try1">收款时间</th>
			</tbody>
			<tbody>
				<tr>
					<td><?php echo $info->create_time;?></td>
					<td><?php echo $info4->fahuotime;?></td>
					<td><?php echo $info4->shouktime;?></td>
				</tr>
			</tbody>
		</table>
	</div>
	
	<!--下单人详细信息-->
	<?php
		$sql3=mysqli_query($conn,"SELECT * FROM tb_order o JOIN tb_user u ON o.u_nickname=u.nickname WHERE order_id='$order_id';");
		$info3=mysqli_fetch_object($sql3);
	?>
	<div class="outline">
		<table class="table" align="center" style="margin-top: 10px;">
			<tr>
				<div class="text-info">
					<h4>下单人</h4>
				</div>
			</tr>
			<thead>
				<th class="try1">昵称</th>
				<th class="try1">姓名</th>
				<th class="try1">送水地址</th>
				<th class="try1">电话1</th>
				<th class="try1">电话2</th>
			</thead>
			<tbody>
				<tr>
					<td><span class="bg-danger"><?php echo $info3->nickname;?></span></td>
					<td><?php echo $info3->name;?></td>
					<td><?php echo $info3->address;?></td>
					<td><?php echo $info3->u_mobile1?></td>
					<td><?php echo $info3->u_mobile2?></td>
				</tr>
			</tbody>
		</table>
	</div>
	
	<!--商品详细信息-->
	<div class="outline">
		<table class="table" align="center" style="margin-top: 10px;">
			<tr>
				<div class="text-info">
					<h4>商品</h4>
				</div>
			</tr>
			<thead>
				<th class="try1">商品品牌</th>
				<th class="try1">规格</th>
				<th class="try1">卖价/元</th>
				<th class="try1">数量</th>
				<th class="try1">小计</th>
			</thead>
			<tbody>
				<tr>
				<?php
					do{
//						$tzs=$info->tzs;
//						echo $tzs;
						$sql2=mysqli_query($conn,"select * from tb_tzs where tzs=".$info->tzs);
						$info_tzs=mysqli_fetch_object($sql2);
				?> 
						<td><?php echo $info_tzs->brand;?></td><!--商品品牌-->
						<td><?php echo $info_tzs->guige;?></td><!--规格-->
						<td><?php echo $info_tzs->tzsmaijia;?></td><!--卖价-->
						<td><?php echo $info->o_num;?></td><!--数量-->
						<td><?php echo $info->xiaoji;?></td><!--小计-->
				</tr>
				<?php
				}while($info=mysqli_fetch_object($sql));
				?>
			</tbody>
		</table>
	</div>
	
	<!--工人信息-->
	<div class="outline">
		<table class="table" align="center" style="margin-top: 10px;">
			<tr>
				<div class="text-info">
					<h4>工人</h4>
				</div>
			</tr>
			<thead>
				<th class="try1">工号</th>
				<th class="try1">姓名</th>
				<th class="try1">性别</th>
				<th class="try1">联系电话</th>
			</thead>
			<tbody>
				<tr>
						<td><?php echo $info4->worker;?></td><!--工号-->
						<td><?php echo $info4->w_name;?></td><!--姓名-->
						<td><?php echo $info4->w_sex;?></td><!--性别-->
						<td><?php echo $info4->w_mobile;?></td><!--联系电话-->
				</tr>
			</tbody>
		</table>
	</div>
	<div style="margin-top: 20px;">
		<button type="button" class="btn btn-primary"><a style="text-decoration: none;color: #fff;" href="giveBadTzsWorker.php?order_id=<?php echo $order_id;?>">坏桶</a></button>
		<button type="button" id="Submit2" class="btn btn-primary"><a href="javascript:history.back();" style="text-decoration: none;color: #fff;">返回</a></button>
	</div>
</body>
</html>