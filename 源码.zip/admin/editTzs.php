<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>编辑商品</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<body id="container">
		<?php	//判断数据库中有无商品
			include("conn/conn.php");
			$sql=mysqli_query($conn,"select count(*) as total from tb_tzs");
			$info = mysqli_fetch_object($sql);
			$total=$info->total;
			if($total==0){	//没有商品
				echo "本站暂无商品！";
			}
			else{	//有商品
		?>
		<?php	//分页显示
	     $pagesize=20;
		   if ($total<=$pagesize){
		      $pagecount=1;
			} 
			if(($total%$pagesize)!=0){
			   $pagecount=intval($total/$pagesize)+1;
			
			}else{
			   $pagecount=$total/$pagesize;
			
			}
			if(!isset($_GET['page'])){
			    $page=1;
			
			}else{
			    $page=intval($_GET['page']);
			
			}
			 
             $sql1=mysqli_query($conn,"select * from tb_tzs limit ".($page-1)*$pagesize.",$pagesize ");
	   ?>
		<p>
			<div class="text-info">
				<h3>编辑商品</h3>
			</div>
		</p>
		<table class="table table-hover outline" align="center" style="margin-top: 10px;">
			<thead>
				<th class="try1">商品品牌</th>
				<th class="try1">规格</th>
				<th class="try1">进价</th>
				<th class="try1">卖价</th>
				<th class="try1">种类</th>
				<th class="try1">剩余数量</th>
				<th class="try1">已卖</th>
				<th class="try1">操作</th>
			</thead>
			<tbody>
				<?php //循环结构，开始
					while($info=mysqli_fetch_object($sql1))
					{
					$tzs = $info->tzs;
					$sql2=mysqli_query($conn,"select * from tb_jinhuo where tb_jinhuo.tzs='$tzs'");
					$info2=mysqli_fetch_object($sql2);
				?>
				<tr><!--循环显示的区域-->
					<td><?php echo $info->brand?></td>
					<td><?php echo $info->guige?></td>
					<td><?php echo $info->tzsjinjia?></td>
					<td><?php echo $info->tzsmaijia?></td>
					<td><?php echo $info->type?></td>
					<td><?php echo $info->t_num?></td>
					<td>
						<!--已卖桶装水数量=原始-剩余的-->
						<?php
							if($info2) {
								//取出进货数量
								$jinhuonum=$info2->jinhuonum;
								//取数剩余的数量 
								$sy_num=$info->t_num;
								echo $jinhuonum-$sy_num;
							}else{
								echo '0';
							}	
						?>
						
					</td>
					<td>
						<button type="button" class="buttoncss"><a href="modifyTzs.php?tzs=<?php echo $info->tzs?>">修改</a></button>
						<button type="button" class="buttoncss"><a style="text-decoration: none;" href="back/delTzs.php?tzs=<?php echo $info->tzs?>">删除</a></button>
					</td>
				</tr>
				<?php	//循环结束
				}
				?>
			</tbody>
		</table>
		<table>
		  <tr>
		    <td>
		    	<div align="left">
					&nbsp;本站共有桶装水&nbsp;<?php echo $total;?>&nbsp;种&nbsp;每页显示&nbsp;<?php echo $pagesize;?>&nbsp;种&nbsp;第&nbsp;<?php echo $page;?>&nbsp;页/共&nbsp;<?php echo $pagecount; ?>&nbsp;页
		        <?php
					if($page!=1){
	//显示首页超链接
						echo "<a href='editUser.php?page=1'>首页</a>&nbsp;";
	//显示“上一页”超链接	
						echo "<a href='editUser.php?page=".($page-1)."'>上一页</a>&nbsp;";
					}
	//如果当前页不是尾页
					if($page<$pagecount){
						echo "<a href='editUser.php?page=".($page+1)."'>下一页</a>&nbsp;";
						echo "<a href='editUser.php?page=".$pagecount."'>尾页</a>&nbsp;";
					}
					mysqli_free_result($sql1);
					mysqli_close($conn);
				?>
				</div>
			</td>
		  </tr>
		</table>
		<?php	//else有用户的情况结束
		}
		?>
	</body>
</html>
