<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>毛利润</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
</head>
<body id="container">
	<!-- 毛利率计算 -->
	<?php include("conn/conn.php"); ?>
	<p>
		<div class="text-info">
			<h3>毛利润</h3>
		</div>
		<div class="text-info">
			<a href="income.php?state=3">按日</a>&nbsp;&nbsp;
			<a href="income.php?state=1">按月</a>&nbsp;&nbsp;
			<a href="income.php?state=2">按年</a>
		</div>
		<br>
	</p>
	<table class="table table-hover outline" align="center" style="margin-top:10px;">
		<thead>
			<th class="try1">总收益/元</th>
			<th class="try1">工人工资/元</th>
			<th class="try1">进货/元</th>
			<th class="try1">时间</th>
			<th class="try1">毛利益/元</th>
		</thead>
		<tbody>
			<?php 
			if((isset($_GET['state']) && $_GET['state']==1) || !isset($_GET['state'])){
				$sql_lr = mysqli_query($conn,"select A.amount, A.year as year1, A.month as month1, B.gz, B.year as year2, B.month as month2, C.jinhuo, C.year as year3, C.month as month3 from (select sum(amount) as amount, date_format(create_time,'%Y') as year, date_format(create_time,'%m') as month from tb_order where status=2 group by month,year) A left outer join (select sum((ticheng+0)*0.01*20*w_num+jbgz) as gz, date_format(time,'%Y') as year, date_format(time,'%m') as month from tb_salary group by month,year) B on (A.year=B.year && A.month=B.month) left outer join (select sum(jinhuonum*tzsjinjia) as jinhuo, date_format(jinhuotime,'%Y') as year, date_format(jinhuotime,'%m') as month from tb_jinhuo join tb_tzs on tb_jinhuo.tzs = tb_tzs.tzs group by month,year) C on (A.year=C.year && A.month=C.month) UNION select A.amount, A.year as year1, A.month as month1, B.gz, B.year as year2, B.month as month2, C.jinhuo, C.year as year3, C.month as month3 from (select sum(amount) as amount, date_format(create_time,'%Y') as year, date_format(create_time,'%m') as month from tb_order where status=2 group by month,year) A right outer join (select sum((ticheng+0)*0.01*20*w_num+jbgz) as gz, date_format(time,'%Y') as year, date_format(time,'%m') as month from tb_salary group by month,year) B on (A.year=B.year && A.month=B.month) right outer JOIN (select sum(jinhuonum*tzsjinjia) as jinhuo, date_format(jinhuotime,'%Y') as year, date_format(jinhuotime,'%m') as month from tb_jinhuo join tb_tzs on tb_jinhuo.tzs = tb_tzs.tzs group by month,year) C on (A.year=C.year && A.month=C.month) order by year1,year2,year3,month1,month2,month3");
			}else if(isset($_GET['state']) && $_GET['state']==2){
				$sql_lr = mysqli_query($conn,"select A.amount, A.year as year1, B.gz, B.year as year2, C.jinhuo, C.year as year3 from (select sum(amount) as amount, date_format(create_time,'%Y') as year from tb_order where status=2 group by year) A left outer join(select sum((ticheng+0)*0.01*20*w_num+jbgz) as gz, date_format(time,'%Y') as year from tb_salary group by year) B on (A.year=B.year) left outer join (select sum(jinhuonum*tzsjinjia) as jinhuo, date_format(jinhuotime,'%Y') as year from tb_jinhuo join tb_tzs on tb_jinhuo.tzs = tb_tzs.tzs group by year) C on (A.year=C.year) UNION select A.amount, A.year as year1, B.gz, B.year as year2, C.jinhuo, C.year as year3 from (select sum(amount) as amount, date_format(create_time,'%Y') as year from tb_order where status=2 group by year) A right outer join (select sum((ticheng+0)*0.01*20*w_num+jbgz) as gz, date_format(time,'%Y') as year from tb_salary group by year) B on (A.year=B.year) right outer JOIN (select sum(jinhuonum*tzsjinjia) as jinhuo, date_format(jinhuotime,'%Y') as year from tb_jinhuo join tb_tzs on tb_jinhuo.tzs = tb_tzs.tzs group by year) C on (A.year=C.year) order by year1,year2,year3");
			}else if(isset($_GET['state']) && $_GET['state']==3){
				$sql_lr = mysqli_query($conn,"select A.amount, A.year as year1,A.month as month1,A.day as day1, B.gz, B.year as year2, B.month as month2, B.day as day2, C.jinhuo, C.year as year3, C.month as month3, C.day as day3 from (select sum(amount) as amount, date_format(create_time,'%Y') as year, date_format(create_time,'%m') as month, date_format(create_time,'%d') as day from tb_order where status=2 group by day,month,year) A left outer join (select sum((ticheng+0)*0.01*20*w_num+jbgz) as gz, date_format(time,'%Y') as year, date_format(time,'%m') as month, date_format(time,'%d') as day from tb_salary group by day,month,year) B on (A.year=B.year && A.month=B.month && A.day=B.day) left outer join (select sum(jinhuonum*tzsjinjia) as jinhuo, date_format(jinhuotime,'%Y') as year, date_format(jinhuotime,'%m') as month, date_format(jinhuotime,'%d') as day from tb_jinhuo join tb_tzs on tb_jinhuo.tzs = tb_tzs.tzs
group by day,month,year) C on (A.year=C.year && A.month=C.month && A.day=C.day) UNION select A.amount, A.year as year1,A.month as month1,A.day as day1, B.gz, B.year as year2, B.month as month2, B.day as day2, C.jinhuo, C.year as year3, C.month as month3, C.day as day3 from (select sum(amount) as amount, date_format(create_time,'%Y') as year, date_format(create_time,'%m') as month, date_format(create_time,'%d') as day from tb_order where status=2 group by day,month,year ) A right outer join (select sum((ticheng+0)*0.01*20*w_num+jbgz) as gz, date_format(time,'%Y') as year, date_format(time,'%m') as month, date_format(time,'%d') as day from tb_salary group by day,month,year) B on (A.year=B.year && A.month=B.month && A.day=B.day) right outer join (select sum(jinhuonum*tzsjinjia) as jinhuo, date_format(jinhuotime,'%Y') as year, date_format(jinhuotime,'%m') as month, date_format(jinhuotime,'%d') as day from tb_jinhuo join tb_tzs on tb_jinhuo.tzs = tb_tzs.tzs group by day,month,year) C on (A.year=C.year && A.month=C.month && A.day=C.day) order by year1,year2,year3,month1,month2,month3,day1,day2,day3");
		}
			
			
			while($info_lr = mysqli_fetch_array($sql_lr)){
				?>
				<tr>
					<td><?php if($info_lr['amount']!=null) echo $info_lr['amount']; else echo '0';?></td>
					<td><?php if($info_lr['gz']!=null) echo $info_lr['gz']; else echo '0';?></td>
					<td><?php if($info_lr['jinhuo']!=null) echo $info_lr['jinhuo']; else echo '0';?></td>
					<td><?php if((isset($_GET['state']) && $_GET['state']==1) || !isset($_GET['state'])){if($info_lr['year1']!=NULL) echo $info_lr['year1'].$info_lr['month1']; else if($info_lr['year2']!=NULL) echo $info_lr['year2'].$info_lr['month2']; else echo $info_lr['year3'].$info_lr['month3'];}else if(isset($_GET['state']) && $_GET['state']==2){if($info_lr['year1']!=NULL) echo $info_lr['year1']; else if($info_lr['year2']!=NULL) echo $info_lr['year2']; else echo $info_lr['year3'];}else if(isset($_GET['state']) && $_GET['state']==3){if($info_lr['year1']!=NULL) echo $info_lr['year1'].$info_lr['month1'].$info_lr['day1']; else if($info_lr['year2']!=NULL) echo $info_lr['year2'].$info_lr['month2'].$info_lr['day2']; else echo $info_lr['year3'].$info_lr['month3'].$info_lr['day3'];} ?></td>
					<td><?php echo $info_lr['amount']-$info_lr['gz']-$info_lr['jinhuo']; ?></td>
				</tr>
				<?php
			}
			?>
		</tbody>
	</table>
</body>
</html>