<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>订单管理-查询订单</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<script type="text/javascript">
		function checkDate(form){
			if(form.txt_keyword.value=="")
			{
				alert("请输入下订单人昵称或者电话号码，或者订单号");
				return false;
			}
		}
	</script>
	<?php
		include("conn/conn.php");
	?>
	<body  id="container">
		<div class="text-info">
			<h3>查询订单</h3>
		</div>
		<div class="outline">
			<form name="form1" method="post" action="findOrder.php" onsubmit="return checkDate(this);">
				<input placeholder="请输入下单人昵称/电话号码/订单号" type="text" class="form-control"  name="txt_keyword"  id="txt_keyword" style="width:250px;display: inline;margin:20px 20px 20px 0px;">
				<input type="submit" class="buttoncss btn btn-primary" name="Submit" id="Submit" value="查询"  />
			</form>
		</div>
		<?php
			//处理查询以后显示的内容
			if(!(empty($_POST['Submit'])))//如果点击了查询后
			{
				$keyword = $_POST["txt_keyword"];
				$sql1=mysqli_query($conn,"SELECT * FROM (SELECT * FROM tb_order o JOIN  tb_user u on o.u_nickname=u.nickname) tb_big WHERE u_nickname like '%".trim($keyword)."%' or u_mobile1 like '%".trim($keyword)."%' or u_mobile2 like '%".trim($keyword)."%' or order_id like '%".trim($keyword)."%'");
				$info=mysqli_fetch_object($sql1);
				if($info==false){
		     		echo "<div algin='center'>对不起,没有查找到该订单!</div>";    
				}else{
		?>
			<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
				<thead>
				     <th class="try1">订单号</th><!--订单id-->
				     <th class="try1">下单人</th><!--昵称-->
				     <th class="try1">提交时间</th>
				     <th class="try1">总额/元</th>
				     <th class="try1">订单状态</th><!--状态，0:未发货，1：已发货，2：未收款，3：已完成-->
				     <th class="try1">操作</th>
				</thead>
				<tbody>
				<?php
					do{
				?>
						<tr>
							<td><?php echo $info->order_id;?></td>
							<td><?php echo $info->nickname;?></td>
							<td><?php echo $info->create_time;?></td>
							<td><?php echo $info->amount;?></td>
							<!--<td><?php echo $info->status;?></td>-->
							<!--<td><?php echo $info->order_id;?></td>-->
							<?php
								//订单状态显示的判断
								if($info->status=='0')
								{
									echo "<td><sapn class='bg-danger'>未发货</sapn></td>";
								}else if($info->status=='1'){
									echo "<td><sapn class='bg-warning'>已发货</sapn></td>";
								}else if($info->status=='2'){
									echo "<td><sapn class='bg-info'>未收款</sapn></td>";
								}else if($info->status=='3'){
									echo "<td><sapn class='bg-success'>已完成</sapn></td>";
								}
							?>
							<td>
								<button type="button" class="buttoncss"><a href="editOrder.php" style="text-decoration: none;">去处理</a></button>
							</td>
						</tr>
				<?php
				}while($info=mysqli_fetch_object($sql1));
				?>
				</tbody>  
			</table>
		<?php
		  }
		 }
		?>
	</body>
</html>
