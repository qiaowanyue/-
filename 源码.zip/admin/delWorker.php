<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>修改工人信息</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<script type="text/javascript">
	</script>
	<body id='container'>
		<?php	//判断数据库中有无工人
			include("conn/conn.php");
			$sql=mysqli_query($conn,"select count(*) as total from tb_worker where status = '0'");
			$info = mysqli_fetch_object($sql);
			$total=$info->total;			
			$time = date("Y-m");	
			if($total==0){	//没有用户
				echo "本站暂无工人！";
			}
			else{	//有工人
		?>
		<p>
			<div class="text-info">
				<h3>修改工人信息</h3>
			</div>
		</p>
		<table class="table table-hover outline" align="center" style="margin-top: 10px;">
			<thead>
				<th class="try1">工号</th>
				<th class="try1">姓名</th>
				<th class="try1">手机号码</th>
				<th class="try1">性别</th>
				<th class="try1">送水提成</th>
				<th class="try1">基本工资</th>
				<th class="try1">已送桶数/桶</th>
				<th class="try1">操作</th>
			</thead>
			<tbody>
				<?php
					$sql1=mysqli_query($conn,"select * from tb_worker w JOIN tb_salary s ON w.worker=s.worker where status = '0' and time LIKE '$time%';");
					while($info=mysqli_fetch_object($sql1))
					{	
				?>
				<tr>
					<td><?php echo $info->worker?></td>
					<td><?php echo $info->w_name?></td>
					<td><?php echo $info->w_mobile?></td>
					<td><?php echo $info->w_sex?></td>
					<td><?php echo $info->ticheng?></td>
					<td><?php echo $info->jbgz?></td>
					<td><?php echo $info->w_num?></td>
					<td>
						<button type="button" class="buttoncss"><a href="back/delWorker.php?worker=<?php echo $info->worker;?>">删除</a></button>
						<!--<button type="button" class="buttoncss">删除</button>-->
					</td>
				</tr>
				<?php
				}
				?>
			</tbody>
		</table>
		<?php
		}
		?>
	</body>
</html>
