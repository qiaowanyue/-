<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>毛利润</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
</head>
<body id="container">
	<?php
		include("conn/conn.php");
		//已卖的数量
//		$sql1=mysqli_query($conn,"SELECT tzs,COUNT(*) as total FROM tb_order o JOIN tb_order_details d WHERE o.`status`=2 GROUP BY tzs;");
//		$info1=mysqli_fetch_object($sql1);
		$sql1 = mysqli_query($conn,"select * from tb_tzs");
	?>
	<!--进货信息-->
	<p>
		<div class="text-info">
			<h3>桶装水</h3>
		</div>
	</p>
	<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
		<thead>
			<th class="try1">品牌</th>
			<th class="try1">规格</th>
			<th class="try1">已卖数量</th>
			<th class="try1">小计/元</th>
		</thead>
		<tbody>
			<?php
				while($info1=mysqli_fetch_object($sql1)){
					//获得进价，卖价，算出利润
					$tzs = $info1->tzs;
//					$sql2=mysqli_query($conn,"SELECT * FROM tb_tzs WHERE tzs='$tzs'");
					$sql2 = mysqli_query($conn,"select tzs,count(*) as total from tb_order join tb_order_details on tb_order.order_id =tb_order_details.order_id where status=2 and tzs='$tzs'");
					$info2=mysqli_fetch_object($sql2);
					$tzs_income=($info1->tzsmaijia)-($info1->tzsjinjia);//桶装水利润
			?>
				<tr>
					<td><?php echo $info1->brand;?></td>
					<td><?php echo $info1->guige;?></td>
					<td><?php echo $info2->total;?></td>
					<td><?php echo ($info2->total)*$tzs_income;?></td>
				</tr>
			<?php
			}
			?>
		</tbody>
	</table>
			
			
		
</body>
</html>