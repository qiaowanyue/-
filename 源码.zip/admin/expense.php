<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>支出成本</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
</head>
<body id="container">
		<ul id="myTab" class="breadcrumb">
			<li class="active">
				<a href="#jh" data-toggle="tab">进货信息</a>
			</li>
			<li>
				<a href="#gz" data-toggle="tab">工资信息</a>
			</li>
			<li>
				<a href="#ht" data-toggle="tab">坏桶损失</a>
			</li>
		</ul>
		<div id="myTabContent" class="tab-content" style="font-size: 12px;">
			<!--进货信息-->
			<div class="tab-pane fade in active" id="jh">
				<p>
					<div class="text-info">
						<h3>进货信息</h3>
					</div>
				</p>
			<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
				<thead>
					<th class="try1">单号</th>
					<th class="try1">进货时间</th>
					<th class="try1">处理人</th>
					<th class="try1">进货时间</th>
					<th class="try1">品牌</th>
					<th class="try1">规格</th>
					<th class="try1">进价</th>
					<th class="try1">数量</th>
					<th class="try1">总计/元</th>
				</thead>
			</table>
			</div>
			
			<!--工资信息-->
			<div class="tab-pane fade" id="gz">
				<p>
					<div class="text-info">
						<h3>工资信息</h3>
					</div>
				</p>
				<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
					<thead>
						<th class="try1">工号</th>
						<th class="try1">姓名</th>
						<th class="try1">基本工资</th>
						<th class="try1">提成工资</th><!--提成工资等于提成乘以送水量-->
						<th class="try1">总工资</th>
					</thead>
				</table>
			</div>
			<!--坏桶损失信息-->
			<div class="tab-pane fade" id="ht">
				<p>
					<div class="text-info">
						<h3>坏桶损失信息</h3>
					</div>
				</p>
				<table  class="table table-hover outline" align="center" style="margin-top: 10px;">
					<thead>
						<th class="try1">品牌</th>
						<th class="try1">规格</th>
						<th class="try1">数量</th>
						<th class="try1">进价</th><!--此处的进价应该是水+桶两个部分的-->
					</thead>
				</table>
			</div>
		</div>
		
</body>
</html>