<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$nickname=$_POST["nickname"];
	$name=$_POST["name"];
	$address=$_POST["address"];
	$u_mobile1=$_POST["mobile1"];
	$u_mobile2=$_POST["mobile2"];
	$sql = mysqli_query($conn,"update tb_user set name='$name',address='$address',u_mobile1='$u_mobile1',u_mobile2='$u_mobile2' where nickname='$nickname'");
//	update主键不能改，必须记得加where条件！！！
	if($sql){
    	echo "<script>alert('用户信息修改成功！');
    	window.location.href='../editUser.php'</script>";
    }else{
    	echo "<script>alert('用户信息修改失败！');
    		window.location.href='modifyUser.php?nickname=$nickname';</script>";
    }
?>