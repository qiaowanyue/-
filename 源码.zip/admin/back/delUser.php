<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$nickName = $_GET["nickname"];
	$sql = mysqli_query($conn,"delete from tb_user where nickname='$nickName'");
	if($sql){
		echo "<script>alert('用户信息删除成功！');window.location.href='../editUser.php';</script>";
	}else{
		echo "<script>alert('用户信息删除失败！');
			history.back();</script>";
	}
	mysqli_close($conn);
?>