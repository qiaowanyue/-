<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$worker = $_POST["worker"];
	$w_name = $_POST["w_name"];
	$w_mobile = $_POST["w_mobile"];
	$w_sex = $_POST["w_sex"];
	$ticheng = $_POST["ticheng"];
	$jbgz = $_POST["jbgz"];
	$w_num=$_POST["w_num"];
	$sql = mysqli_query($conn,"update tb_worker set w_name='$w_name',w_mobile='$w_mobile',w_sex='$w_sex' where worker='$worker'");
	$sql2 = mysqli_query($conn,"update tb_salary set ticheng='$ticheng',jbgz='$jbgz',w_num='$w_num' where worker='$worker'");
//	update主键不能改，必须记得加where条件！！！
	if($sql && $sql2){
    	echo "<script>alert('工人信息修改成功！');
    	window.location.href='../editWorker.php'</script>";
    }else{
    	echo "<script>alert('工人信息修改失败！请重试！');
    		window.location.href='../modifyWorker.php?worker=$worker';</script>";    
	}
?>