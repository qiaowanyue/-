<meta charset="utf-8" />
<?php
	include("../conn/conn.php");
	
	$arry1 = array();	//为小括号，定义空数组
	$arry2 = array();
	$arry3 = array();
	$i = 0;
	
	$now = date('Y-m',time());
	$time=date('Y-m-d H:i:s',time());
	$lastM = date("Y-m",strtotime("last month"));
	
	/* 找出工人表中未删除的工人,放入数组$arry1中 */
	$sql = mysqli_query($conn,"SELECT * FROM tb_worker WHERE `status` = '0';");
	while($info = mysqli_fetch_object($sql))
	{
		$arry1[$i] = $info->worker;
		$i++;
	}
	$i = 0;
	//	var_dump($arry1) ;

	/* 找出工资表中本年本月的工人id，放入数组$arry2中 */
	$sql2 = mysqli_query($conn,"SELECT * FROM tb_salary WHERE time LIKE '$now%' ;");
	while($info2 = mysqli_fetch_object($sql2))
	{
		$arry2[$info2->s_id] = $info2->worker;
		$i++;
	}
//		var_dump($arry2) ;

	/* 若数组1在数组2中找不到此工人id，就将工人id放入数组3中  */
	foreach ($arry1 as $key => $val)
	{
	    if(!in_array($val,$arry2))	// php内置函数中有一个array_diff()：意思比较两个数组的键值，并返回差集。
	    {
	        $arry3[] = $arry1[$key];	//将本年本月在工资表中没有记录的工人id，放入数组3中
	    }
	}
//	var_dump($arry3) ;

	/* 根据数组3的id，在表中添加记录  */
	foreach ($arry3 as $key => $val)
	{
	    $worker = $arry3[$key];	//工人id
	    //找上一个月的工资作为参考
	    $sql3 = mysqli_query($conn,"SELECT * FROM tb_salary WHERE time LIKE '$lastM%' AND worker='$worker' ;");
	    $info3 = mysqli_fetch_object($sql3);
	    $sql4 = mysqli_query($conn,"INSERT into tb_salary (ticheng,jbgz,time,worker) VALUES ('$info3->ticheng','$info3->jbgz','$time','$info3->worker');");
	}
	
	
	echo json_encode($sql4);
	mysqli_free_result($sql);
	mysqli_free_result($sql2);
	mysqli_free_result($sql3);
	mysqli_close($conn);
?>