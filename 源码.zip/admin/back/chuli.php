<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	session_start();		//启动session
	include("../conn/conn.php");
	$admin = $_SESSION["adminzhanghao"];
	$order_id = $_POST["order_id"];
	$worker = $_POST["worker"];
	$s_id = $_POST["s_id"];
	$time=date('Y-m-d H:i:s',time());//发货时间
		$sql1=mysqli_query($conn,"insert into tb_chuli (order_id,worker,fahuoadmin,fahuotime) values ('$order_id','$worker','$admin','$time')");
		$sql2=mysqli_query($conn,"update tb_order set status='1' where order_id='$order_id'");
//更新工人送水桶数
$num_sql=mysqli_query($conn,"SELECT d.order_id,SUM(o_num) num FROM tb_order_details d JOIN tb_order o ON d.order_id=o.order_id WHERE d.order_id='$order_id' GROUP BY d.order_id;");
$num_info=mysqli_fetch_object($num_sql);
$num=$num_info->num;
//echo $s_id;
		$sql3=mysqli_query($conn,"update tb_salary set w_num=w_num+'$num' where s_id='$s_id'");
		if($sql1 && $sql2 && $sql3){
	    	echo "<script>alert('订单派发成功！');
	  	window.location.href='../editOrder.php'</script>";
	    }else{
	    	echo "<script>alert('订单派发失败！');
	  		window.location.href='../giveWorker.php?order_id=$order_id';</script>";
	    }
	
	
?>