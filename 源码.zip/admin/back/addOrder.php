<meta charset="utf-8" />
<?php
	include("../conn/conn.php");
	session_start();
//	$order_id=$_POST["order_id"];//订单号
//	$time=time();//获取提交时间的时间戳
	$time=date('Y-m-d H:i:s',time());
	$amount = 0;//总计为0
	$sql=0;
	$nickname = $_POST["nickname"];//下单人昵称
	//得到下单人的电话1
	$m_sql=mysqli_query($conn,"select u_mobile1 from  tb_user where nickname='$nickname'");
	$m_info=mysqli_fetch_object($m_sql);
	$mobile1=$m_info->u_mobile1;//取出电话1·
	$order_id=$mobile1.time();//订单号由电话1和提交时间生成
	foreach($_REQUEST as $k =>$num){//$k是input中的name名！！！$num是选的桶装水的数量！将前端所有传过来的值都变遍历了一遍
		if($num!=0 && is_numeric($num) && is_numeric($k)){//当$k为数值的时候（代表是数量的input的name），且当桶装水的数量不为0
			$sql2=mysqli_query($conn,"select tzsmaijia from tb_tzs where tzs='$k'");
			$info=mysqli_fetch_object($sql2);
//			echo $info;
			if($info){
				$tzsmaijia=$info->tzsmaijia;
				$xiaoji =$num * $tzsmaijia;//小计，假设为20元
				$amount+=$xiaoji;//计算总计
				//添加记录到订单详情表中
				$sql = mysqli_query($conn,"insert into tb_order_details (order_id,tzs,o_num,xiaoji) values ('$order_id','$k','$num','$xiaoji')");
			}else{
				echo "找不到卖价"; 
			}
		}
	}
	//添加信息到订单表中
	$sql3 = mysqli_query($conn,"insert into tb_order (order_id,u_nickname,amount,status,create_time) values ('$order_id','$nickname','$amount','0','$time')");
	if($sql && $sql3){
    	echo "<script>alert('订单信息添加成功！');
    	window.location.href='../editOrder.php'</script>";
    }else{
    	echo "<script>alert('订单信息添加失败！');
    		window.location.href='../addOrder.php';</script>";
    }
?>