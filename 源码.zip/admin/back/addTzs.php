<meta charset="utf-8" />
<?php
	session_start();
	include("../conn/conn.php");
	$admin = $_SESSION["adminzhanghao"];//管理员账号
	$time=date('Y-m-d H:i:s',time());//进货时间
	$brand = $_POST["brand"];
	$guige = $_POST["guige"];
	$tzsjinjia = $_POST["tzsjinjia"];
	$tzsmaijia = $_POST["tzsmaijia"];
	$t_num = $_POST["num"];//进货数量
	$type = $_POST["type"];
	$brief = $_POST["jianjie"];
	$image = $_FILES["zp"]["name"];//照片文件名
	//添加到用户的文件中
	if(!is_dir("../../images"))
	{
		mkdir("../../images");
	}
	$path2 = "../../images/".$_FILES["zp"]["name"];
	move_uploaded_file($_FILES["zp"]["tmp_name"],$path2);
	if($image == '')
	{
		$image = 'moren.jpg';
	}
	$sc_image='images/'.$image;
			
		$sql=mysqli_query($conn,"insert into tb_tzs (brand,guige,tzsjinjia,tzsmaijia,t_num,type,image,brief) values ('$brand','$guige','$tzsjinjia','$tzsmaijia','$t_num','$type','$sc_image','$brief')");
		if($sql){
			//如果桶装水添加成功，查询刚刚添加的内容中tzs的id号，以便于添加tb_jinhuo进货表的记录
			$sql2=mysqli_query($conn,"SELECT tzs FROM tb_tzs where brand='$brand' and guige='$guige'");
			$info2=mysqli_fetch_object($sql2);
			$tzs=$info2->tzs;
			$sql3=mysqli_query($conn,"insert into tb_jinhuo (tzs,admin,jinhuotime,jinhuonum) values ('$tzs','$admin','$time','$t_num')");
		}
		if($sql && $sql3){
			echo "<script>alert('桶装水信息添加成功！');window.location.href='../addtzs.html';</script>";
		}
		else
		{
			echo "<script>alert('桶装水信息添加失败！');
			history.back();</script>";
		}

	mysqli_close($conn);
?>