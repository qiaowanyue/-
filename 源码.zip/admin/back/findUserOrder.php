<?php
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$mobile = $_POST["mobile"];
	if(!empty($mobile)){
		$sql=mysqli_query($conn,"select * from tb_user where u_mobile1='$mobile' or u_mobile2='$mobile'");
		$result = array();	//为小括号，定义空数组
		while($row = mysqli_fetch_object($sql)){
			$result[] = $row;
		}
		echo json_encode($result);
		mysqli_free_result($sql);
		mysqli_close($conn);
	}else{
		echo "电话不能空！";
	}
?>