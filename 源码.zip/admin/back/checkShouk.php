<meta charset="utf-8" />
<?php
	include("../conn/conn.php");
	session_start();
	$admin = $_SESSION["adminzhanghao"];//管理员账号
	$order_id=$_GET["order_id"];//订单号
	$time=date('Y-m-d H:i:s',time());//收款时间
	$sql=mysqli_query($conn,"update tb_chuli set shoukadmin='$admin',shouktime='$time' where order_id='$order_id'");
	$sql2=mysqli_query($conn,"update tb_order set status='2' where order_id='$order_id'");
	//剩余数量减少
	$sql3=mysqli_query($conn,"select * from tb_order_details where order_id='$order_id'");
	$info3=mysqli_fetch_object($sql3);
	//循环一个订单中每个商品的剩余数量变化，以及空桶数量的增加
	do{
		$o_num=$info3->o_num;//取出商品的数量
		$tzs=$info3->tzs;
		//目前的数量=之前的-商品的数量
		$sql4=mysqli_query($conn,"update tb_tzs set t_num=t_num-'$o_num' where tzs='$tzs'");
		$sql6=mysqli_query($conn,"select * from tb_empty where tzs='$tzs'");
		$info6=mysqli_fetch_object($sql6);
		if(!$info6)//tb_empty表中没有改tzs的数据，所以需要插入inset into
		{
			$sql7=mysqli_query($conn,"insert into tb_empty (tzs,e_shounum) values ('$tzs','$o_num')");
		}else{//tb_empty表中有tzs的数据，所以需要更新收取数量
			$sql5=mysqli_query($conn,"update tb_empty set e_shounum=e_shounum+'$o_num' where tzs='$tzs'");
		}

	}while($info3=mysqli_fetch_object($sql3));
	if($sql && $sql2 && $sql4 && $sql5 ){
    	echo "<script>alert('订单收款成功！');
	window.location.href='../editOrder.php'</script>";
    }else{
    	echo "<script>alert('订单收款失败！')</script>;
		window.location.href='../editOrder.php'</script>";
    }
?>