<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$tzs = $_POST["tzs"];
	$brand = $_POST["brand"];
	$guige = $_POST["guige"];
	$tzsjinjia = $_POST["tzsjinjia"];
	$tzsmaijia = $_POST["tzsmaijia"];
	$type = $_POST["type"];
	$t_num = $_POST["t_num"];
	$brief = $_POST["jianjie"];
	$sql = mysqli_query($conn,"update tb_tzs set brand='$brand',guige='$guige',tzsjinjia='$tzsjinjia',tzsmaijia='$tzsmaijia',type='$type',t_num='$t_num',brief='$brief' where tzs='$tzs'");
	if($sql){
		echo "<script>alert('桶装水信息修改成功！');
		 window.location.href='../editTzs.php';</script>";
	}else{
		echo "<script>alert('桶装水信息修改失败！'); 
			window.location.href='../modifyWorker.php?tzs=$tzs';</script>";
	}
?>
