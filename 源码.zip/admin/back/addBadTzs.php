<meta charset="utf-8" />
<?php
	include("../conn/conn.php");
	$order_id=$_POST["order_id"];//订单id
	$worker=$_POST["worker"];//工号
	$s_id = $_POST["s_id"];
	//tb_chuli表更新badTzsWorker字段
	$sql=mysqli_query($conn,"update tb_chuli set badTzsWorker='$worker' where order_id='$order_id'");
	//给工人添加送水桶数
	
	//tb_order表更新status从2到3
	$sql2=mysqli_query($conn,"update tb_order set status='3' where order_id='$order_id'");
	$sql4=0;$sql6=0;
	foreach($_REQUEST as $k =>$num){//$k是input中的name名！！！$num是选的桶装水的数量！将前端所有传过来的值都变遍历了一遍
		if($num!=0 && is_numeric($num) && is_numeric($k)){//当$k为数值的时候（代表是数量的input的name），且当桶装水的数量不为0
			//tb_order_details表中更新$k的bad_num
			$sql7=mysqli_query($conn,"update tb_order_details set bad_num='$num'  where tzs='$k'");
			
			//更改剩余数量
			$sql8=mysqli_query($conn,"update tb_tzs set t_num=t_num-'$num' where tzs='$k'");
			//更改工人送水量
//			$sql9=mysqli_query($conn,"update tb_worker set w_num=w_num+'$num' where worker='$worker'");
			$sql9=mysqli_query($conn,"update tb_salary set w_num=w_num+'$num' where s_id='$s_id'");
			$sql3=mysqli_query($conn,"select * from tb_bad where tzs='$k'");
			$info3=mysqli_fetch_object($sql3);
			if(!$info3)//tb_bad表中没有改tzs的数据，所以需要插入inset into
			{
				$sql4=mysqli_query($conn,"insert into tb_bad (tzs,tb_shounum) values ('$k','$num')");
			}else{//tb_bad表中有tzs的数据，所以需要更新收取数量
				$sql5=mysqli_query($conn,"select tb_shounum from tb_bad where tzs='$k'");
				$info5=mysqli_fetch_object($sql5);
				$oldNum=$info5->tb_shounum;//取出该桶装水之前的坏桶数量
				$newNum=$oldNum+$num;//目前的数量
				$sql6=mysqli_query($conn,"update tb_bad set tb_shounum='$newNum' where tzs='$k'");//更新数量
			}
		}
	}
	if(($sql && $sql2  && $sql4 && $sql7 && $sql8 && $sql9) || ($sql && $sql2  && $sql6 && $sql7 && $sql8 && $sql9)){
    	echo "<script>alert('坏桶信息添加成功！');
    	window.location.href='../editOrder.php'</script>";
    }else{
    	echo "<script>alert('坏桶信息添加失败！');
    		window.location.href='../giveBadTzsWorker.php?order_id=$order_id';</script>";
    }
?>