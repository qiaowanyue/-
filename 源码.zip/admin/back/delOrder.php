<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$order_id=$_GET["order_id"];
	$sql1=mysqli_query($conn,"delete from tb_order where order_id='$order_id'");
	$sql2=mysqli_query($conn,"delete from tb_order_details where order_id='$order_id'");
	if($sql1 && $sql2){
		echo "<script>alert('订单信息删除成功！');window.location.href='../editOrder.php';</script>";
	}else{
		echo "<script>alert('订单信息删除失败！');
			history.back();</script>";
	}
	mysqli_close($conn);
?>