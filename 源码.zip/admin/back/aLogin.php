<?php	
	session_start();		//启动session
	include("../conn/conn.php");
	header ("Content-type: text/html; charset=utf-8");
	header('Content-Type:application/json; charset=utf-8');
	$zhanghao = $_POST['zhanghao'];
	$pwd = $_POST['pwd'];                                                                                                                            
	$sql = mysqli_query($conn,"select zhanghao,a_pwd from tb_admin where zhanghao='$zhanghao' AND a_pwd = '$pwd'");
	$result = array();		//数组是为了前端好调用
	while($row = mysqli_fetch_object($sql)){		//将用户昵称保存到session数组里面，以便后面用户操作可直接调用
		$result[] = $row;
		if($row!=null){			//$row来判断
		$_SESSION["adminzhanghao"] = $row->zhanghao;
		}
	}
	
	echo json_encode($result);
	
	mysqli_free_result($sql);
	mysqli_close($conn);
?>