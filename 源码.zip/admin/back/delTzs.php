<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$tzs = $_GET["tzs"];
	$sql = mysqli_query($conn,"delete from tb_tzs where tzs='$tzs'");
	if($sql){
		echo "<script>alert('桶装水信息删除成功！');window.location.href='../editTzs.php';</script>";
	}else{
		echo "<script>alert('桶装水信息删除失败！');
			history.back();</script>";
	}
	mysqli_close($conn);
?>