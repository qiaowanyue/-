<?php
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$nickname = $_POST["nickname"];
	$name=$_POST["name"];
	$address=$_POST["address"];
	$mobile1=$_POST["mobile1"];
	$mobile2=$_POST["mobile2"];
	$sql = mysqli_query($conn,"insert into tb_user (nickname,name,address,u_mobile1,u_mobile2,u_pwd,u_head) values ('$nickname','$name','$address','$mobile1','$mobile2','NULL',NULL)");
	echo json_encode($sql);		//echo($sql)返回1，加了json_encode后才返回的是true 或false
	mysqli_close($conn);
?>