<meta charset="utf-8" />
<?php
	include("../conn/conn.php");
	$worker = $_POST["worker"];
	$w_name = $_POST["w_name"];
	$w_sex = $_POST["w_sex"];
	$jbgz = $_POST["jbgz"];
	$w_mobile = $_POST["w_mobile"];
	$ticheng = $_POST["ticheng"];
	$time=date('Y-m-d H:i:s',time());
	
	$sql = mysqli_query($conn,"insert into tb_worker (worker,w_name,w_sex,w_mobile) values ('$worker','$w_name','$w_sex','$w_mobile')");
    $sql2 = mysqli_query($conn,"INSERT into tb_salary (ticheng,jbgz,time,worker) VALUES ('$ticheng','$jbgz','$time','$worker');");
	
	
	if($sql && $sql2){
		echo "<script>alert('工人信息添加成功！');
		 window.location.href='../editWorker.php';</script>";
	}else{
		echo "<script>alert('工人信息添加失败！'); 
			window.location.href='../addWorker.php';</script>";
	}
?>