<meta charset="utf-8" />	<!--注意写这句！！！不然js代码无效-->
<?php
	include("../conn/conn.php");
	$worker = $_GET["worker"];
	$sql = mysqli_query($conn,"UPDATE tb_worker SET `status` = '1' WHERE worker='$worker'");
	if($sql){
		echo "<script>alert('工人信息删除成功！');window.location.href='../delWorker.php';</script>";
	}else{
		echo "<script>alert('工人信息删除失败！');
			history.back();</script>";
	}
	mysqli_close($conn);
?>