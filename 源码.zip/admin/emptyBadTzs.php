<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>空桶坏桶查看数量</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/editOrder.css" rel="stylesheet">
	<body  id="container">
		<div class="text-info">
			<h3>空桶坏桶查看</h3>
		</div>
	</body>
	<form name="form1" onSubmit="" method="post" action="">
		<table class="table table-hover outline" align="center" style="margin-top: 10px;">
			<thead>
				<th class="try1">商品</th>
				<th class="try1">规格</th>
				<th class="try1">空桶数/桶</th>
				<th class="try1">坏桶数/桶</th>
			</thead>
			<tbody>
				<?php
					include("conn/conn.php");
					//商品
					$sql=mysqli_query($conn,"select * from tb_tzs");
					$info=mysqli_fetch_object($sql);
					if(!$info)
					{
		     			echo "<div algin='center' style='color: red;'>本站暂无商品!</div>";    
					}
					else{
						
				?>
				<?php
					do{
						//空桶数
						$sql2=mysqli_query($conn,"SELECT * FROM tb_empty e JOIN tb_tzs t ON e.tzs=t.tzs where t.tzs='$info->tzs';");
						$info2=mysqli_fetch_object($sql2);
						//坏桶数
						$sql3=mysqli_query($conn,"SELECT * FROM tb_bad e JOIN tb_tzs t ON e.tzs=t.tzs where t.tzs='$info->tzs';");
						$info3=mysqli_fetch_object($sql3);
				?>
				<tr>
					<td><?php echo $info->brand;?></td>
					<td><?php echo $info->guige;?></td>
					<!--//空桶-->
					<?php
						if(empty($info2->e_shounum))
						{
							echo "<td>0</td>";
						}else{
					?>
					<td><?php echo $info2->e_shounum;?></td>
					<?php
						}
					?>
					<!--坏桶-->
					<?php
						if(empty($info3->tb_shounum))
						{
							echo "<td>0</td>";
						}else{
					?>
					<td><?php echo $info3->tb_shounum;?></td>
					<?php
						}
					?>
					
				</tr>
				<?php
				}while($info=mysqli_fetch_object($sql));
				?>
			</tbody>
		</table>
		<div style="margin-top: 20px;">
			<!--<input type="submit" name="submit" id="Submit" value="修改" class="btn btn-primary"/>-->
		</div>
	</form>
	<?php
		}
	?>
</html>
