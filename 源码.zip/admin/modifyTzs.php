<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>修改商品信息</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<link href="css/addtzs.css" rel="stylesheet">
	<script>
		function checkDate(form){
			if(form.brand.value=="")
			{
				alert("请输入商品品牌！");
				form.brand.focus();
				return false;
			}
			if(form.guige.value=="")
			{
				alert("请输入规格！");
				form.guige.focus();
				return false;
			}else if(/^\s*$/.test(form.guige.value)){
				alert("规格不能全为空格！");
				form.guige.focus();
				return false;
			}else if(!(/^[0-9]{1,}.?[0-9]{0,2}(L|ML|l|ml|升|毫升){1}$/.test(form.guige.value)))
			{
				alert("规格只能是数字，且有单位l或者ml或者升毫升！");
				form.guige.focus();
				return false;
			}
			if(form.tzsjinjia.value=="")
			{
				alert("请输入进价！");
				form.tzsjinjia.focus();
				return false;
			}else if(/^\s*$/.test(form.tzsjinjia.value)){
				alert("进价不能全为空格！");
				form.tzsjinjia.focus();
				return false;
			}else if(!(/^[0-9]{1,}.?[0-9]{0,2}$/.test(form.tzsjinjia.value)))
			{
				alert("进价只能是数字，且只有两位小数！");
				form.tzsjinjia.focus();
				return false;
			}
			//卖价的判断
			if(form.tzsmaijia.value=="")
			{
				alert("请输入卖价！");
				form.tzsmaijia.focus();
				return false;
			}else if(/^\s*$/.test(form.tzsmaijia.value)){
				alert("卖价不能全为空格！");
				form.tzsmaijia.focus();
				return false;
			}else if(!(/^[0-9]{1,}.?[0-9]{0,2}$/.test(form.tzsmaijia.value)))
			{
				alert("卖价只能是数字，且只有两位小数！");
				form.tzsmaijia.focus();
				return false;
			}
			//类型的判断
			if(form.type.value=="")
			{
				alert("请输入类型！");
				form.type.focus();
				return false;
			}else if(/^\s*$/.test(form.type.value)){
				alert("类型不能全为空格！");
				form.type.focus();
				return false;
			}
			//剩余数量的判断
			if(form.t_num.value=="")
			{
				alert("剩余数量不能为0！");
				form.t_num.focus();
				return false;
			}else if(!(/^[0-9]*$/.test(form.t_num.value))){
				alert("剩余数量为整数！");
				form.t_num.focus();
				return false;
			}
		}
	</script>
	<?php
		include("conn/conn.php");
		$tzs=$_GET["tzs"];	//取出桶装水id
		$sql=mysqli_query($conn,"select * from tb_tzs t JOIN  tb_jinhuo j  on j.tzs=t.tzs where t.tzs='$tzs'");
//		if (!$sql) {
//  	printf("Error: %s\n", mysqli_error($conn));
//	    exit();
//}
		$info=mysqli_fetch_object($sql);
	?>
	<body id="container">
		<p>
			<div class="text-info">
				<h3>修改商品信息</h3>
			</div>
		</p>
		<div class="outline">
		<!--将onSubmit写在form表单中代替onclik写在input中。防止表单的刷新-->
			<form name="form1" onSubmit="return checkDate(this)" method="post" action="back/changeTzs.php">
				<table align="center" style="margin-top: 10px;" border="1px" width="460px">
					<tr>
						<td>商品品牌：</td>
						<td align="center">
							<input type="hidden" name="tzs" id="tzs" value="<?php echo $info->tzs;?>"/>
							<input value="<?php echo $info->brand;?>"type="text" class="form-control" name="brand" id="brand" style="border-color: #93BEE2;width: 270px;"/>
						</td>
					</tr>
					<tr>
						<td>规格：</td>
						<td align="center">
							<input value="<?php echo $info->guige;?>" type="text" class="form-control" name="guige" id="guige" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>进价：</td>
						<td align="center">
							<input value="<?php echo $info->tzsjinjia;?>" type="text" class="form-control" name="tzsjinjia" id="tzsjinjia" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>卖价：</td>
						<td align="center">
							<input value="<?php echo $info->tzsmaijia;?>" type="text" class="form-control" name="tzsmaijia" id="tzsmaijia" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>种类：</td>
						<td align="center">
							<input value="<?php echo $info->type;?>" type="text" class="form-control" name="type" id="type" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>剩余数量：</td>
						<td align="center">
							<input value="<?php echo $info->t_num;?>" type="text" class="form-control" name="t_num" id="t_num" style="border-color: #93BEE2;width: 270px; "/>
						</td>
					</tr>
					<tr>
						<td>已卖：</td>
						<td  align="center">
						<!--已卖桶装水数量=原始-剩余的-->
						<?php
							//取出进货数量
							$jinhuonum=$info->jinhuonum;
							//取数剩余的数量 
							$sy_num=$info->t_num;
							$num=$jinhuonum-$sy_num;
							echo '<input value="'.$num.'" type="text" class="form-control" name="num" id="num" style="border-color: #93BEE2;width: 270px; "/>';
						?>
					</td>
					</tr>
					<tr>
						<td>简介：</td>
						<td align="center">
							<input value="<?php echo $info->brief;?>" type="text" class="form-control" name="jianjie" id="jianjie" style="border-color: #93BEE2;width: 270px; "placeholder="纯净"/>
						</td>
					</tr>
				</table>	
				<div style="margin-top: 20px;">
					<input type="submit" name="submit" id="Submit" value="修改" class="btn btn-primary"/>
					<button type="button" id="Submit2" class="btn btn-primary"><a href="javascript:history.back();" style="text-decoration: none;color: #fff;">取消</a></button>
				</div>
			</form>
		</div>
	</body>
</html>