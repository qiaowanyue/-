<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>添加订单</title>
	</head>
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../js/jquery.form.min.js" type="text/javascript"></script>
	<link href="css/addtzs.css" rel="stylesheet">
	<link href="css/editOrder.css" rel="stylesheet">
	<?php
		session_start();
		include("conn/conn.php");
	?>
	<script>
		window.onload = function(){
			var arrPlus = document.getElementsByClassName("plus");//取加号的对象
			for(var i=0;i<arrPlus.length;i++){//遍历循环
				arrPlus[i].onclick = function(){//当加号被点击
					//取被点击节点的兄弟节点的方法，为父节点的子节点
					var valueNum = this.parentNode.getElementsByClassName('menunum')['0'];//取出文本框对象
					valueNum.value = parseInt(valueNum.value) + 1;
				}
			}
			//减
			var arrMinus = document.getElementsByClassName("minus");//取减号的对象
			for(var i=0;i<arrMinus.length;i++){//遍历循环
				arrMinus[i].onclick = function(){//当减号被点击
					var valueNum = this.parentNode.getElementsByClassName('menunum')['0'];
					if(valueNum.value == 0){
						alert("数值已最小");
						return false;//让程序停止运行
					}
					else{
						valueNum.value = parseInt(valueNum.value) - 1;
					}
				}
			}
		}
		function checkDate(form){
			if(form.nickname.value==""){
				alert("订单人不能为空,请点击查看！");
				form.nickname.focus();
				return false;
			}
			if(form.address.value==""){
				alert("地址不能为空，请点击查看！");
				form.address.focus();
				return false;
			}
			if(form.nickname.value=="" || form.nickname.value==undefined || form.address.value=="" || form.address.value==undefined){
				alert("请点击查看！");
				form.mobile.focus();
				return false;
			}
		}
		function findDate(form){
			var mobile = document.getElementById("mobile").value;
			var nickname = document.getElementById("nickname");
			var address = document.getElementById("address");
			if(form.mobile.value==""){
				alert("电话不能为空！");
				form.mobile.focus();
				return false;
			}else if(!(/^1[3456789]\d{9}$/.test(form.mobile.value)))
			{
				alert("电话格式错误，请重新输入！");
				form.mobile.focus();
				return false;
			}else{
				var xhr = new XMLHttpRequest();
				xhr.open("POST","back/findUserOrder.php",true);
				xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
				xhr.send("mobile="+mobile);
				xhr.onreadystatechange = function(){
				if(xhr.status==200 && xhr.readyState==4){
					var data = xhr.responseText;
					console.log(typeof data);
					console.log(data);
					data = JSON.parse(data);
					console.log(data);
					if(data.length==1 && data[0].nickname && data[0].address){
						nickname.value=data[0].nickname;
						address.value=data[0].address;
						return true;
					}else{
						alert("本站无此电话号码的信息，请再次确定或添加新用户！");//添加用户
						document.getElementById("mobile").focus();
						return false;
					}
					
				}
			  }
			}
		}
		function addCheck(form){
			var mobile = document.getElementById("mobile").value;
			if(form.mobile.value==""){
				alert("电话不能为空！");
				form.mobile.focus();
				return false;
			}else if(!(/^1[3456789]\d{9}$/.test(form.mobile.value)))
			{
				alert("电话格式错误，请重新输入！");
				form.mobile.focus();
				return false;
			}else{
			var xhr = new XMLHttpRequest();
			xhr.open("POST","back/findUserOrder.php",true);
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
			xhr.send("mobile="+mobile);
			xhr.onreadystatechange = function(){
				if(xhr.status==200 && xhr.readyState==4){
					var data = xhr.responseText;
					console.log(typeof data);
					console.log(data);
					data = JSON.parse(data);
					console.log(data);
					if(data.length==0){
						var a = document.getElementsByClassName("buttoncss")[1];
//						a.href="addUser.php?mobile=form.mobile.value";
						window.location.href="addUser.php?mobile="+form.mobile.value;
					}else{
						alert("此用户已存在，不能添加");
					}
				}
		  	  }
			}
		}
	</script>
	<body id='container'>
		<div class="text-info">
			<h3>添加订单</h3>
		</div>
		<div class="outline">
			<form name="form1" onSubmit="return checkDate(this);" method="post" action="back/addOrder.php"> 
			<table align="center" border="1px" width="460px" style="margin-bottom: 20px;">
				<tr>
					<div class="text-info">
						<h4>订单</h4>
					</div>
				</tr>
				<tr>
					<td>联系电话：</td><!--必写，若数据库中存在，直接写出下单人昵称以及地址。若不存在直接提示。-->
					<td align="center">
						<input type="text" class="form-control" name="mobile" id="mobile"  style="border-color: #93BEE2;width: 185px;display: inline;" />
						<button type="button" class="buttoncss" style="display: inherit;"  onclick="findDate(form1);">查看</button>
						<button type="button" class="buttoncss" style="display: inherit;"  onclick="addCheck(form1);">添加</button>
					</td>
				</tr>
				<tr>
					<td>下单人：</td><!--可不写-->
					<td align="center">
						<input  readonly="readonly" type="text" class="form-control" name="nickname" id="nickname"  style="border-color: #93BEE2;width: 270px; " placeholder="通过联系电话查询得到，无需输入"/>
					</td>
				</tr>
				<tr>
					<td>地址：</td><!--可不写-->
					<td align="center">
						<input  readonly="readonly"  type="text" class="form-control" name="address" id="address"  style="border-color: #93BEE2;width: 270px; " placeholder="通过联系电话查询得到，无需输入"/>
					</td>
				</tr>
				<tr>
					<td>订单号：</td>
					<td align="center">
						<input type="text" class="form-control" name="order_id" id="order_id"  style="border-color: #93BEE2;width: 270px; " readonly="readonly" placeholder="订单号自动随机生成，无需输入"/>
					</td>
				</tr>

			</table>
		</div>
		<?php
			$sql=mysqli_query($conn,"select count(*) as total from tb_tzs");
			$info = mysqli_fetch_object($sql);
			$total=$info->total;
			if($total==0){	//没有商品
				echo "本站暂无商品！";
			}
			else{	//有商品
		?>
		<div class="outline">
			<table class="table" align="center" style="margin-top: 10px;">
				<tr>
					<div class="text-info">
						<h4>商品</h4>
					</div>
				</tr>
				<thead>
					<th class="try1">商品品牌</th>
					<th class="try1">规格</th>
					<th class="try1">数量</th>
				</thead>
				<tbody>
					<?php
						$sql1=mysqli_query($conn,"select * from tb_tzs order by brand");
						while($info=mysqli_fetch_object($sql1))
						{
							$_SESSION["mnum".$info->tzs] = 0; 
					?>
					<tr>
						<td><?php echo $info->brand;?></td>
						<td><?php echo $info->guige?></td>
						<td>
							<span class="plus" style="cursor:pointer"><!--style="cursor:pointer"鼠标变为手指-->
								＋
							</span>
							<input style="width: 30px;" class="span1 menunum" type="text" name="<?php echo $info->tzs;?>" id="<?php echo $info->tzs;?>" value="0" />
							<span class="minus" style="cursor:pointer">
								—
							</span>
						</td>
					</tr>	
					<?php
					}
					?>
				</tbody>	
			</table>
		</div>
			<div style="margin-top: 20px;">
				<input type="submit" name="Submit" id="Submit"  value="添加"/ class="btn btn-primary"/>
				<button class="btn btn-primary" type="button"><a href="javascript:location.reload();"style="color: #fff; text-decoration:none;">重置</a></button>
			</div>
		</form>
		<?php
		}
		?>
		
	</body>
</html>
