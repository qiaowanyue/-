/* 将数组转化成json字符串的封装函数（递归） */
function arrToJSON(arr) {

    var json = {};

    for (var i in arr) {

        var vo=arr[i];

        if (typeof arr[i] == "object") {

            json[i]={};

            json[i] = arrToJSON(vo);

        } else {

            json[i] =vo;

        }

    }

    return JSON.stringify(json);

}