<?php
//	检测用户是否登录
	session_start();
//	include("../conn/conn.php"); 
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	//判断session数组中的userNickName是否设置
	if(!isset($_SESSION["userNickName"])){			//session数组中的userNickName未设置，用户未登录	
		$data['status']="error";
	}else{		//用户已登录	
		$data['status']="ok";
		$data['data'] = $_SESSION['userNickName'];
	}
	echo json_encode($data);
?>