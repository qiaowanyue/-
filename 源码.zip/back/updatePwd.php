<?php
	session_start();
	include("../conn/conn.php");
	header ("Content-type: text/html; charset=utf-8");
	header('Content-Type:application/json; charset=utf-8');
	$u_pwd = md5($_POST["newPwd"]);
//	$u_pwd = md5('1111111');
	$nickName = $_SESSION["userNickName"];
//	$nickName = '111';
	$sql = mysqli_query($conn,"update tb_user set u_pwd = '$u_pwd' where  nickname = '$nickName'");
//		7fa8282ad93047a4d6fe6111c93b308a
	echo json_encode($sql);
	mysqli_close($conn);
?>