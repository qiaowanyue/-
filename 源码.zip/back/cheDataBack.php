<?php
//	登录时检测昵称密码是否正确
	session_start();
	include("../conn/conn.php");
	header ("Content-type: text/html; charset=utf-8");
	header('Content-Type:application/json; charset=utf-8');
	$u_pwd = md5($_POST["oldPwd"]);
//	$u_pwd = md5('1111111');
	$nickName = $_SESSION["userNickName"];
//	$nickName = '111';
	$sql = mysqli_query($conn,"select nickname,u_pwd from tb_user where u_pwd = '$u_pwd' and nickname = '$nickName'");
	$result = array();		//数组是为了前端好调用
	while($row = mysqli_fetch_object($sql)){		//将用户昵称保存到session数组里面，以便后面用户操作可直接调用
		$result[] = $row;
	}
		
	echo json_encode($result);
	
	mysqli_free_result($sql);
	mysqli_close($conn);
?>