<?php
	if(!isset($_SESSION)){ session_start();}
	echo "<meta charset='UTF-8'>";
	include("../conn/conn.php");
	
	$a1=$_POST['address1'];
	$a2=$_POST['address2'];
	$a3=$_POST['address3'];
	$a4=$_POST['address4'];
	$a5=$_POST['address5'];
	$nickname = $_SESSION["userNickName"];
	
	$sql = mysqli_query($conn,"update tb_user set tb_user.address='$a1' where tb_user.nickname='$nickname'");
	
	$sql2 = mysqli_query($conn,"select * from tb_ss_address where tb_ss_address.nickname='$nickname'");
	if($info2 = mysqli_fetch_object($sql2)){
		$sql3 = mysqli_query($conn,"update tb_ss_address set address_con1='$a2',address_con2='$a3',address_con3='$a4',address_con4='$a5' where nickname='$nickname'");
	}else{
		$sql3 = mysqli_query($conn,"insert into tb_ss_address (address_id,nickname,address_con1,address_con2,address_con3,address_con4) values (NULL,'$nickname','$a2','$a3','$a4','$a5')");	
	}
	
	
	if($sql && $sql3){
		echo "<script>alert('修改成功！');window.location='../geren.php';</script>";
	}else{
		echo "<script>alert('修改失败！');history.back();</script>";
		
	}
?>