<?php
//	检测用户昵称是否重复
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$nickname = $_POST["nickname"];
	$sql = mysqli_query($conn,"select nickname from tb_user where nickname = '$nickname'");
	$result = array();	//为小括号，定义空数组
	while($row = mysqli_fetch_object($sql)){
		$result[] = $row;
	}
	echo json_encode($result);
	mysqli_free_result($sql);
	mysqli_close($conn);
?>