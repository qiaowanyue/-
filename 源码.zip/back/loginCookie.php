<?php
	header ("Content-type: text/html; charset=utf-8");
	header('Content-Type:application/json; charset=utf-8');
//	$nickname=
//	$time30=time()+24*60*60*30;	//建立cookie
//	setcookie("NickName","$nickname","$time30");
//	setcookie("Pwd","pwd","$time30");   
	$nicknameCookie = $_COOKIE["NickName"];
	$pwdCookie = $_COOKIE["Pwd"];
	$result = array("showNickName" => "$nicknameCookie","showPwd" => "$pwdCookie");		//定义关联数组
	echo json_encode($result);
?>