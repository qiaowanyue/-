<?php
if(!isset($_SESSION)) session_start();
echo "<meta charset='UTF-8'>";
include("../conn/conn.php");

$nickname = $_SESSION['userNickName'];

$n_con = "address_con".$_GET['id'];


$sql = mysqli_query($conn,"select * from tb_user where tb_user.nickname='$nickname'");
$sql2 = mysqli_query($conn,"select * from tb_ss_address where tb_ss_address.nickname='$nickname'");
$info = mysqli_fetch_object($sql);
$info2 = mysqli_fetch_object($sql2);
$address = $info->address;
$address_mr = $info2->$n_con;


$sql1_1_query = "update tb_ss_address set tb_ss_address.".$n_con."='$address' where tb_ss_address.nickname='$nickname'";
$sql1_1 = mysqli_query($conn,$sql1_1_query);
$sql1_2 = mysqli_query($conn,"update tb_user set tb_user.address='$address_mr'");

if($sql1_1 && $sql1_2){
	echo "<script>alert('设置成功！');window.location='../geren.php';</script>";
}else{
	echo "<script>alert('设置失败！');history.back();</script>";
}

?>