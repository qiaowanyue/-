<?php
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$name = $_POST["name"];
	$nickName = $_SESSION["userNickName"];
	$tel1=$_POST["tel1"];
	$tel2=$_POST["tel2"];
	$sql = mysqli_query($conn,"update tb_user set name='$name',u_mobile1='$tel1',u_mobile2='$tel2' where  nickname = '$nickName'");
	echo json_encode($sql);		//echo($sql)返回1，加了json_encode后才返回的是true 或false

	mysqli_close($conn);
?>