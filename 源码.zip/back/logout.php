<?php
	header ("Content-type: text/html; charset=utf-8");
	session_start();		//启动session
	session_destroy();	
	echo '<script>window.location.href="../index.html"; alert("注销成功！");</script>';

?>