<?php
	/* 将用户选择的桶装水的信息订单显示  */
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	if(!isset($_SESSION['userNickName'])){
		echo "false";
		exit;
	}else{
		$result = array();
		$amount = 0;		////订单总价钱初值
		$tzsNumsAndId = $_POST["tzsNumsAndId"];		//获取前端传过来的json字符串（里面有桶装水id和相应数量的信息）
		$tzsNumsAndId = json_decode($tzsNumsAndId);		//json字符串转成json对象（调用的形式是“对象名->属性名”）
		$sql = "select tzs,brand,tzsmaijia,type from tb_tzs where t_num>0";		//查询桶装水id，品牌，卖价，类型
		$query = mysqli_query($conn,$sql);
		$i=0;
		while($info = mysqli_fetch_object($query)){
			$tzsId = $info->tzs; 
			$tzs = "tzs".$tzsId;		//$tzsNumsAndId中的属性名：字符串"tzs"+桶装水的id
			$tzsNum = $tzsNumsAndId->$tzs;		//$tzsNumsAndId中的属性值：选择的桶装水数量
			$tzsMaijia = $info->tzsmaijia;
			$xiaoji = $tzsMaijia*$tzsNum;		//每种桶装水小计
			if($xiaoji>0){		//该桶装水的小计大于0，即有选购该桶装水
				$amount += $xiaoji;
				$result[] = $info;
				$result[$i]->xiaoji = $xiaoji;
				$result[$i]->tzsNum = $tzsNum;
				$i++;
			}
		}
		$result[0]->amount = $amount;
		echo json_encode($result);
	}
	mysqli_free_result($query);
	mysqli_close($conn);
?>