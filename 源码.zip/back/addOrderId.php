<?php
//	将订单id存放在session中
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	if(!isset($_POST['orderId'])){
		echo "false";
	}else{
		$orderId = $_POST['orderId'];
		$_SESSION['orderId'] = $orderId;
		echo "true";
		echo $_SESSION['orderId'];
	}
?>