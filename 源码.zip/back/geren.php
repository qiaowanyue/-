<?php
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$sql = mysqli_query($conn,"select * from tb_user where nickname= ".$_SESSION["userNickName"].";");
	$result = array();
	while($row = mysqli_fetch_object($sql)){
		$result[] = $row;
		if($row->u_mobile2 == ""){
			$row->u_mobile2 = "无";
		}
	}
	echo json_encode($result);
	mysqli_free_result($sql);
	mysqli_close($conn);
?>