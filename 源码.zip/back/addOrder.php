<?php
	/* 处理用户提交的订单，添加到数据库的订单表和订单详情表中  */
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	if(!isset($_SESSION['userNickName'])){
		echo "false";
		exit;		//不执行下面的程序
	}else{
		$nickname = $_SESSION['userNickName'];		//用户昵称
	}
	
	/* 查找用户的电话1 */
	$usql1 = "select * from tb_user where nickname = '$nickname'";
	$uquery = mysqli_query($conn,$usql1);
	$uRow = mysqli_fetch_object($uquery);
	if($uRow){
		$mobile1 = $uRow->u_mobile1;
	}
	
	$tzsNumsAndId = $_POST["tzsNumsAndId"];		//获取前端传过来的json字符串（里面有桶装水id和相应数量的信息）
	$tzsNumsAndId = json_decode($tzsNumsAndId);		//json字符串转成json对象（调用的形式是“对象名->属性名”）
//	var_dump($tzsNumsAndId);
	$time = time();		//获取当前提交订单时间的时间戳
	$create_time = date("Y-m-d H:i:s",time());
	$orderId = $mobile1.$time;		//订单id（由用户昵称和购买时间）
	$amount=0;		//订单总价钱初值
	$sql = "select tzs from tb_tzs where t_num>0";
	$query = mysqli_query($conn,$sql);
	while($info = mysqli_fetch_object($query)){
		$tzsId = $info->tzs; 
		if($tzsId){
			$tzs = "tzs".$tzsId;		//$tzsNumsAndId中的属性名：字符串"tzs"+桶装水的id
			$tzsNum = $tzsNumsAndId->$tzs;		//$tzsNumsAndId中的属性值：选择的桶装水数量
//			var_dump($tzsNum);
//			var_dump($tzsNumsAndId);
			$sql1 = "select tzsmaijia from tb_tzs where tzs=".$tzsId;
	    	$sqlqry = mysqli_query($conn,$sql1);		//查询相应桶装水的卖价
	    	$sRow = mysqli_fetch_object($sqlqry);
	    	if($sRow){
	    		$tzsMaijia = $sRow->tzsmaijia;
				$xiaoji = $tzsMaijia*$tzsNum;		//每种桶装水小计
				if($xiaoji>0){
					$amount += $xiaoji;		//计算订单总价钱
					$iql = "insert into tb_order_details (order_id,tzs,o_num,xiaoji) values ('$orderId','$tzsId','$tzsNum','$xiaoji')";
					$usql = mysqli_query($conn,"UPDATE tb_tzs SET t_num = t_num - '$tzsNum' WHERE tzs = '$tzsId';");
					$iresult = mysqli_query($conn,$iql);
				}else{
					continue;
				}
			}else{
				echo "error4";
				exit;
			}
		}else{
			echo "桶装水id不存在";
			exit;
		}
	}
	
	//插入订单表
	$iql2 = "insert into tb_order (order_id,u_nickname,amount,create_time) values ('$orderId','$nickname','$amount','$create_time')";
	$iresult2 = mysqli_query($conn, $iql2);
	if(!$iresult2){
		echo "error....";
	}else{
		echo "true";
	}
	mysqli_free_result($query);
	mysqli_free_result($uquery);
	mysqli_free_result($sqlqry);
	mysqli_close($conn);
?>