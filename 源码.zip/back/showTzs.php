<?php
	include("../conn/conn.php");
	include("chinesesubstr.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$sql = mysqli_query($conn,"select * from tb_tzs where t_num>0");
	$result = array();
	$i=0;
	while($row = mysqli_fetch_object($sql)){
		$row->shortBrief = chinesesubstr($row->brief,10);		//手动添加的新属性shortBrief，是为了显示简介内容的前一些字
		$tzsId = $row->tzs;		//桶装水id
		$time = date('Y-m').'-01';		//当前时间的月初的年月日
//		echo $time;
		$nextTime = date('Y').'-0'.(date('m')+1).'-01';		//获取当前时间的下个月月初的年月日（between and范围不包括右边边界）
//		echo $nextTime;
		/* 查询本月内的月销量 */
		$sql1 = "select sum(o_num) monthNum from tb_order_details d JOIN tb_order o on d.order_id = o.order_id where tzs=$tzsId AND create_time BETWEEN $time AND $nextTime";
		$query1 = mysqli_query($conn,$sql1);
		$info = mysqli_fetch_object($query1);
		$monthNum = $info->monthNum;
//		echo json_encode($info);
		$row->monthNum = $monthNum;		//手动添加的新属性monthNum，是为了显示本月内的月销量
		$result[] = $row;		//将桶装水信息装入$result数组中
		$i++;
	}
	echo json_encode($result);
	mysqli_free_result($sql);
	mysqli_free_result($query1);
	mysqli_close($conn);
?>