<?php
	/* 查询用户所有的订单，在前端判断状态，分别显示在未发货、已发货、已完成界面 */
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	if(!isset($_SESSION['userNickName'])){
		echo "false";
		exit;
	}else{
		$nickname = $_SESSION['userNickName'];
		$result = array();
		$sql = "select * from tb_order where u_nickname = '$nickname' order by create_time desc";		//查询此用户的所有订单，状态在前端判断（即只用写一个后）
		$query = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_object($query)){
			$result[] = $row;
		}
		echo json_encode($result);
	}
	mysqli_free_result($query);
	mysqli_close($conn);
?>