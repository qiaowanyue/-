<?php
	session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	if(empty($_SESSION['orderId'])){
		echo "false";
	}else{
		$orderId = $_SESSION['orderId'];
		$result = array();
		$sql = "select o.order_id,brand,type,guige,tzsmaijia,o_num,xiaoji,amount from tb_order o join tb_order_details d on d.order_id = o.order_id join tb_tzs t on d.tzs = t.tzs where o.order_id = '$orderId'";
		$query = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_object($query)){
			$result[] = $row;
		}
		echo json_encode($result);
	}
	mysqli_free_result($query);
	mysqli_close($conn);
?>