<?php
//改变订单状态
 session_start();
	include("../conn/conn.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	if(!isset($_POST['orderId'])){
		echo "false";
	}else{
		
//		$orderId = $_POST['orderId'];
//		$sql=mysqli_query($conn,"select * from tb_order where order_id='$orderId'");
//		$result=mysqli_fetch_object($sql);
//		$create_time=$result->create_time;
//		$time_now=time();//当前时间戳
//		$time_out=strtotime($create_time);//提交订单时间戳
//		$time_have=$time_now-$time_out;
//		$hour=floor($time_have/60);//将时间戳转化为分钟
//		echo json_encode($hour);
		$orderId = $_POST['orderId'];
		$now=date("Y-m-d H:i:s");
		$sql=mysqli_query($conn,"update tb_order set remind_status=1,remind_time='$now' where order_id='$orderId'");	
		echo json_encode($sql);
	}
?>