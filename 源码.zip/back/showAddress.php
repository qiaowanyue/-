<?php
	session_start();		//启动session
	include("../conn/conn.php");
	include("chinesesubstr.php");
	header ( "Content-type: text/html; charset=utf-8" );
	header('Content-Type:application/json; charset=utf-8');
	$userNickName = $_SESSION["userNickName"];
	$sql = mysqli_query($conn,"SELECT * FROM tb_user WHERE nickname = '$userNickName';");
	$result = array();
//	$i=0;
	while($row = mysqli_fetch_object($sql)){
		$result[] = $row->address;	//默认地址
	}
	$sql2 = mysqli_query($conn,"SELECT * FROM tb_ss_address WHERE nickname = '$userNickName';");
	while($row2 = mysqli_fetch_object($sql2)){
		$result2[] = $row2;	
	}
//	var_dump($result2);
	for($i=1;$i<5;$i++){
		$address_con = 'address_con'.$i;
//		echo $result2[0]->$address_con;
		$address = $result2[0]->$address_con;
		if($address){
			$result[] = $address;
		}
	}
//$i=1;
//echo 'address_con'.$i;
	echo json_encode($result);
	mysqli_free_result($sql);
//	mysqli_free_result($query1);
	mysqli_close($conn);
?>